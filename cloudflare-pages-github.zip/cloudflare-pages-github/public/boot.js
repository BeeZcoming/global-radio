try{
  var __b=location.href.split('#')[0].split('?')[0];
  if(/^https?:$/i.test(location.protocol)){
    var __u=new URL('public-iptv-og.png',__b).href;
    var __ms=document.querySelectorAll('meta[property="og:image"],meta[name="twitter:image"]');
    for(var __i=0;__i<__ms.length;__i++) __ms[__i].content=__u;
    var __c=document.getElementById('seoCanonical'); if(__c) __c.href=__b;
  }
}catch(e){}
