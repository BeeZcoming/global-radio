(function(){
'use strict';

/* ============================ 默认配置 ============================ */
const CONF = {
  iptv:'https://iptv-org.github.io/iptv/index.m3u',
  radio:'https://github.com/BeeZcoming/global-radio/tree/main/data',
  radioMode:'auto',
  lang:'zh',
  limit:5000
};
// Radio Browser 官方镜像（官方器文档建议先做 DNS 节点发现，浏览器无法查 DNS，故用已知节点轮询）
const API_NODES = [
  'https://de1.api.radio-browser.info',
  'https://de2.api.radio-browser.info',
  'https://fi1.api.radio-browser.info',
  'https://at1.api.radio-browser.info',
  'https://all.api.radio-browser.info',
  'https://api.radio-browser.info'
];
// 6 个地区文件覆盖全球；americas 与 north/south 重复，curated 是 25 MB 全集，都不拉
const RADIO_FILES = [
  'africa-stations.json','oceania-stations.json','south-america-stations.json',
  'asia-stations.json','north-america-stations.json','europe-stations.json'
];

/* ============================ 多语言（界面文案） ============================ */
const LANGS = [
  {id:'zh', label:'简体中文', code:'ZH', html:'zh-CN', intl:'zh-CN'},
  {id:'en', label:'English',  code:'EN', html:'en',    intl:'en-US'},
  {id:'ja', label:'日本語',   code:'JA', html:'ja',    intl:'ja-JP'},
  {id:'ko', label:'한국어',   code:'KO', html:'ko',    intl:'ko-KR'},
  {id:'es', label:'Español',  code:'ES', html:'es',    intl:'es-ES'},
  {id:'fr', label:'Français', code:'FR', html:'fr',    intl:'fr-FR'},
  {id:'de', label:'Deutsch',  code:'DE', html:'de',    intl:'de-DE'},
  {id:'ru', label:'Русский',  code:'RU', html:'ru',    intl:'ru-RU'}
];
// TSV：key / zh / en / ja / ko / es / fr / de / ru ；~ 表示回退英文
const I18N_RAW = `
brand	公共电视 · 广播	Public TV & Radio	公共テレビ・ラジオ	공공 TV · 라디오	TV y Radio Pública	Télé & Radio Publiques	Öffentliches TV & Radio	Общественное ТВ и Радио
brand_short	公共电视	Public TV	公共テレビ	공공 TV	TV Pública	Télé Publique	Öffentl. TV	Общ. ТВ
nav_tv	电视	TV	テレビ	TV	TV	TV	TV	ТВ
nav_radio	电台	Radio	ラジオ	라디오	Radio	Radio	Radio	Радио
nav_list	频道列表	Channels	チャンネル一覧	채널 목록	Canales	Chaînes	Kanäle	Каналы
nav_label	主导航	Main navigation	メインナビゲーション	주 탐색	Navegación principal	Navigation principale	Hauptnavigation	Главная навигация
chip_tip	点击管理数据源	Click to manage data sources	クリックでデータソースを管理	클릭하여 데이터 소스 관리	Clic para gestionar fuentes	Cliquer pour gérer les sources	Klicken zum Verwalten der Quellen	Нажмите для управления источниками
lang_label	界面语言	Interface language	表示言語	인터페이스 언어	Idioma de la interfaz	Langue de l'interface	Sprache der Oberfläche	Язык интерфейса
lang_menu_title	选择界面语言	Choose interface language	表示言語を選択	인터페이스 언어 선택	Elegir idioma	Choisir la langue	Sprache wählen	Выбрать язык
btn_settings	数据源	Sources	データソース	데이터 소스	Fuentes	Sources	Quellen	Источники
btn_import	导入 M3U	Import M3U	M3U を読み込む	M3U 가져오기	Importar M3U	Importer M3U	M3U importieren	Импорт M3U
btn_export	导出 M3U	Export M3U	M3U を書き出す	M3U 내보내기	Exportar M3U	Exporter M3U	M3U exportieren	Экспорт M3U
btn_close	关闭	Close	閉じる	닫기	Cerrar	Fermer	Schließen	Закрыть
btn_surprise	✦ 随便看看	✦ Surprise me	✦ おまかせ	✦ 아무거나	✦ Sorpréndeme	✦ Surprends-moi	✦ Überrasch mich	✦ Удиви меня
btn_find_tv	找频道 →	Find channels →	チャンネルを探す →	채널 찾기 →	Buscar canales →	Trouver des chaînes →	Kanäle finden →	Найти каналы →
btn_find_radio	找电台 →	Find stations →	ラジオ局を探す →	방송국 찾기 →	Buscar emisoras →	Trouver des stations →	Sender finden →	Найти станции →
eyebrow_tv	全球电视直播 · 在线	Live TV worldwide · Online	世界のテレビ生放送 · オンライン	전 세계 TV 생중계 · 온라인	TV en directo mundial · En línea	TV en direct mondiale · En ligne	Weltweites Live-TV · Online	ТВ в прямом эфире · Онлайн
eyebrow_radio	全球网络电台 · 在线	Internet radio worldwide · Online	世界のネットラジオ · オンライン	전 세계 인터넷 라디오 · 온라인	Radio web mundial · En línea	Radios web mondiales · En ligne	Weltweites Webradio · Online	Интернет-радио мира · Онлайн
h1_tv	世界正在直播。<em>去一个没去过的地方。</em>	The world is live.<em>Go somewhere new.</em>	世界はいま生放送。<em>まだ知らない場所へ。</em>	세계가 지금 생방송 중.<em>가보지 못한 곳으로.</em>	El mundo está en vivo.<em>Ve a algún lugar nuevo.</em>	Le monde est en direct.<em>Partez vers un ailleurs.</em>	Die Welt sendet live.<em>Entdecke einen neuen Ort.</em>	Мир в прямом эфире.<em>Отправься туда, где не бывал.</em>
h1_radio	去别处听听。<em>换一种声音。</em>	Listen somewhere new.<em>Find a different sound.</em>	どこか別の場所で聴く。<em>違う音を。</em>	다른 곳의 소리를 들어보세요.<em>새로운 소리로.</em>	Escucha en otro lugar.<em>Otro sonido.</em>	Écoutez ailleurs.<em>Un autre son.</em>	Hör woanders hin.<em>Ein anderer Klang.</em>	Послушайте в другом месте.<em>Другой звук.</em>
lead_tv	一点好奇心，换来一整个世界的电视直播。	A little curiosity opens up a world of live TV.	少しの好奇心で、世界のテレビ生放送が広がる。	작은 호기심으로 전 세계 TV 생중계를 만나보세요.	Un poco de curiosidad abre un mundo de TV en directo.	Un peu de curiosité ouvre un monde de TV en direct.	Ein wenig Neugier öffnet eine Welt voller Live-TV.	Немного любопытства открывает мир прямого эфира.
lead_radio	在地球上选一个地方，或者让下一座电台自己找上门。	Pick a place on the globe, or let the next station find you.	地球の上から場所を選ぶか、次のラジオ局に任せて。	지구에서 한 곳을 고르거나 다음 방송국이 찾아오게 하세요.	Elige un lugar del mapa o deja que la próxima emisora te encuentre.	Choisissez un point du globe ou laissez la prochaine station venir à vous.	Wähle einen Ort auf dem Globus oder lass den nächsten Sender dich finden.	Выберите точку на глобусе или позвольте следующей станции найти вас.
sub_tv	在地球上选一个点，或者让宇宙替你挑一个。	Pick a dot on the globe, or let the universe choose.	地球上の点を選ぶか、宇宙に選んでもらって。	지구 위에 점을 찍거나 우주에 맡겨보세요.	Elige un punto del globo o deja que el universo decida.	Choisissez un point ou laissez l'univers décider.	Wähle einen Punkt oder lass das Universum entscheiden.	Выберите точку или доверьтесь вселенной.
sub_radio	来自世界各地的声音，无需注册即可收听。	Voices from everywhere, free and no sign-up.	世界中の声を、登録なしで。	전 세계의 소리를 가입 없이 들으세요.	Voces de todo el mundo, gratis y sin registro.	Des voix du monde entier, gratuitement et sans inscription.	Stimmen aus aller Welt, kostenlos und ohne Anmeldung.	Голоса со всего мира, бесплатно и без регистрации.
seo_note	收录 iptv-org 公开 M3U 电视直播列表与 Radio Browser 社区网络电台，按国家、分类、语言检索；支持 HLS 在线播放、频道收藏与播放列表导出。	A public directory of iptv-org live TV channels and Radio Browser internet stations. Browse by country, category and language, play HLS streams, save favourites and export M3U playlists.	~	~	~	~	~	~
noscript	本站需要在浏览器中启用 JavaScript 才能加载频道目录与播放器。	JavaScript is required to load the channel directory and the player.	~	~	~	~	~	~
globe_loading	正在载入频道目录…	Loading directory…	ディレクトリを読み込み中…	목록을 불러오는 중…	Cargando directorio…	Chargement du répertoire…	Verzeichnis wird geladen…	Загрузка каталога…
globe_hint_tv	拖动旋转 · 滚轮缩放 · 点击国家光点筛选频道	Drag to rotate · Scroll to zoom · Tap a country dot to filter	ドラッグで回転 · ホイールでズーム · 国の点で絞り込み	드래그로 회전 · 휠로 확대 · 국가 점을 눌러 필터	Arrastra para girar · Rueda para acercar · Toca un país para filtrar	Glisser pour tourner · Molette pour zoomer · Cliquer un pays pour filtrer	Ziehen zum Drehen · Scrollen zum Zoomen · Land antippen zum Filtern	Перетащите для вращения · Колесо для масштаба · Нажмите страну для фильтра
globe_hint_radio	拖动旋转 · 滚轮缩放 · 点击国家光点筛选电台	Drag to rotate · Scroll to zoom · Tap a country dot to filter	ドラッグで回転 · ホイールでズーム · 国の点で絞り込み	드래그로 회전 · 휠로 확대 · 국가 점을 눌러 필터	Arrastra para girar · Rueda para acercar · Toca un país para filtrar	Glisser pour tourner · Molette pour zoomer · Cliquer un pays pour filtrer	Ziehen zum Drehen · Scrollen zum Zoomen · Land antippen zum Filtern	Перетащите для вращения · Колесо для масштаба · Нажмите страну для фильтра
globe_hint_mobile	单指旋转 · 双指缩放 · 点一下地图查看列表	One finger to rotate · Pinch to zoom · Tap the map for the list	1 本指で回転 · ピンチでズーム · 地図をタップで一覧	한 손가락으로 회전 · 핀치로 확대 · 지도를 탭하면 목록	Un dedo para girar · Pellizca para zoom · Toca el mapa para ver la lista	Un doigt pour tourner · Pincer pour zoomer · Toucher la carte pour la liste	Ein Finger dreht · Zwei Finger zoomen · Karte antippen für Liste	Одним пальцем вращать · Щипок для масштаба · Нажмите на карту для списка
foot_big_tv	一颗星球，数不尽的故事。	One planet, countless stories.	ひとつの惑星、数えきれない物語。	하나의 행성, 셀 수 없는 이야기.	Un planeta, innumerables historias.	Une planète, d'innombrables histoires.	Ein Planet, unzählige Geschichten.	Одна планета, бесчисленные истории.
foot_big_radio	一颗星球，数不尽的频率。	One planet, countless frequencies.	ひとつの惑星、数えきれない周波数。	하나의 행성, 셀 수 없는 주파수.	Un planeta, innumerables frecuencias.	Une planète, d'innombrables fréquences.	Ein Planet, unzählige Frequenzen.	Одна планета, бесчисленные частоты.
foot_sub	聚合公开直播源，本站不托管任何内容	Aggregating public streams; we host no content	公開ストリームを集約、当サイトは配信しません	공개 스트림을 모으며 콘텐츠는 호스팅하지 않습니다	Agregamos fuentes públicas; no alojamos contenido	Agrégation de flux publics ; nous n'hébergeons rien	Bündelt öffentliche Streams; wir hosten keine Inhalte	Агрегируем открытые потоки; контент не размещаем
foot_watch_tv	无需注册即可观看	Watch free, no sign-up	登録なしで視聴できます	가입 없이 시청하세요	Ver gratis y sin registro	Regarder gratuitement, sans inscription	Kostenlos ansehen, ohne Anmeldung	Смотрите бесплатно без регистрации
foot_watch_radio	无需注册即可收听	Listen free, no sign-up	登録なしで聴けます	가입 없이 들으세요	Escuchar gratis y sin registro	Écouter gratuitement, sans inscription	Kostenlos hören, ohne Anmeldung	Слушайте бесплатно без регистрации
foot_live_tv	电视直播	Live TV	テレビ生放送	TV 생중계	TV en directo	TV en direct	Live-TV	ТВ в эфире
foot_live_radio	电台直播	Live radio	ラジオ生放送	라디오 생중계	Radio en directo	Radio en direct	Live-Radio	Радио в эфире
dock_label	频道工具	Channel tools	チャンネルツール	채널 도구	Herramientas	Outils de chaînes	Kanal-Werkzeuge	Инструменты каналов
dock_list	频道列表	Channels	チャンネル一覧	채널 목록	Canales	Chaînes	Kanäle	Каналы
dock_filter	筛选与搜索	Filter & search	絞り込みと検索	필터 및 검색	Filtrar y buscar	Filtrer et rechercher	Filtern & Suchen	Фильтр и поиск
dock_fav	只看收藏	Favourites only	お気に入りのみ	즐겨찾기만	Solo favoritos	Favoris uniquement	Nur Favoriten	Только избранное
dock_next	下一个频道	Next channel	次のチャンネル	다음 채널	Siguiente canal	Chaîne suivante	Nächster Kanal	Следующий канал
dock_refresh	刷新数据源	Refresh sources	データソースを更新	데이터 소스 새로고침	Actualizar fuentes	Actualiser les sources	Quellen aktualisieren	Обновить источники
panel_label	频道列表与筛选	Channel list and filters	チャンネル一覧と絞り込み	채널 목록 및 필터	Lista y filtros de canales	Liste et filtres des chaînes	Kanalliste und Filter	Список каналов и фильтры
panel_title_tv	找下一个频道	Find your next channel	次のチャンネルを探す	다음 채널 찾기	Encuentra tu próximo canal	Trouvez votre prochaine chaîne	Finde den nächsten Kanal	Найдите следующий канал
panel_title_radio	找下一座电台	Find your next station	次のラジオ局を探す	다음 방송국 찾기	Encuentra tu próxima emisora	Trouvez votre prochaine station	Finde den nächsten Sender	Найдите следующую станцию
panel_desc_tv	按国家、分类、语言浏览全球电视频道。	Browse live TV channels by country, category and language.	国・分類・言語から世界のテレビ局を探せます。	국가·분류·언어로 전 세계 TV 채널을 둘러보세요.	Explora canales de TV por país, categoría e idioma.	Parcourez les chaînes TV par pays, catégorie et langue.	Live-TV-Kanäle nach Land, Kategorie und Sprache durchsuchen.	Телеканалы по стране, категории и языку.
panel_desc_radio	按国家、标签、语言浏览全球网络电台。	Browse internet radio by country, tag and language.	国・タグ・言語から世界のラジオ局を探せます。	국가·태그·언어로 전 세계 라디오를 둘러보세요.	Explora radios web por país, etiqueta e idioma.	Parcourez les radios web par pays, tag et langue.	Webradio nach Land, Tag und Sprache durchsuchen.	Интернет-радио по стране, тегу и языку.
search_ph	搜索频道、国家、分类、语言…	Search channels, countries, categories, languages…	チャンネル・国・分類・言語を検索…	채널·국가·분류·언어 검색…	Buscar canales, países, categorías, idiomas…	Rechercher chaînes, pays, catégories, langues…	Kanäle, Länder, Kategorien, Sprachen suchen…	Поиск каналов, стран, категорий, языков…
f_country	全部国家 / 地区	All countries / regions	すべての国・地域	모든 국가 / 지역	Todos los países / regiones	Tous les pays / régions	Alle Länder / Regionen	Все страны / регионы
f_cat	全部分类	All categories	すべての分類	모든 분류	Todas las categorías	Toutes les catégories	Alle Kategorien	Все категории
f_lang	全部语言	All languages	すべての言語	모든 언어	Todos los idiomas	Toutes les langues	Alle Sprachen	Все языки
btn_reset	重置筛选	Reset filters	絞り込みをリセット	필터 초기화	Restablecer filtros	Réinitialiser les filtres	Filter zurücksetzen	Сбросить фильтры
btn_fav_off	☆ 只看收藏	☆ Favourites only	☆ お気に入りのみ	☆ 즐겨찾기만	☆ Solo favoritos	☆ Favoris uniquement	☆ Nur Favoriten	☆ Только избранное
btn_fav_on	★ 只看收藏	★ Favourites only	★ お気に入りのみ	★ 즐겨찾기만	★ Solo favoritos	★ Favoris uniquement	★ Nur Favoriten	★ Только избранное
btn_export_cur	↓ 导出当前结果	↓ Export results	↓ 結果を書き出す	↓ 결과 내보내기	↓ Exportar resultados	↓ Exporter les résultats	↓ Ergebnisse exportieren	↓ Экспорт результатов
more	加载更多	Load more	さらに読み込む	더 보기	Cargar más	Charger plus	Mehr laden	Показать ещё
empty	没有匹配结果。<br />试试重置筛选，或到「数据源」刷新目录。	No matches.<br />Try resetting filters or refresh the directory in Sources.	一致する結果がありません。<br />フィルターをリセットするか、データソースを更新してください。	일치하는 결과가 없습니다.<br />필터를 초기화하거나 데이터 소스를 새로고침하세요.	Sin resultados.<br />Prueba a restablecer los filtros o actualizar las fuentes.	Aucun résultat.<br />Réinitialisez les filtres ou actualisez les sources.	Keine Treffer.<br />Filter zurücksetzen oder Quellen aktualisieren.	Ничего не найдено.<br />Сбросьте фильтры или обновите источники.
src_count	{0} 个源	{0} sources	{0} ソース	{0} 개 소스	{0} fuentes	{0} sources	{0} Quellen	{0} источников
src_count_one	{0} 个源	{0} source	{0} ソース	{0} 개 소스	{0} fuente	{0} source	{0} Quelle	{0} источник
panel_count_fmt	共 {0} {1} · {2}	Total {0} {1} · {2}	合計 {0} {1} · {2}	총 {0} {1} · {2}	Total {0} {1} · {2}	Total {0} {1} · {2}	Gesamt {0} {1} · {2}	Всего {0} {1} · {2}
panel_result_fmt	当前结果 {0} 条，显示 {1} 条 · 可用性以本机为准	{0} matches, showing {1} · Availability depends on your device	該当 {0} 件、表示 {1} 件 · 再生可否は端末によります	결과 {0}개, {1}개 표시 · 재생 가능 여부는 기기에 따라 다릅니다	{0} resultados, mostrando {1} · La disponibilidad depende de tu dispositivo	{0} résultats, {1} affichés · La disponibilité dépend de votre appareil	{0} Treffer, {1} angezeigt · Verfügbarkeit geräteabhängig	{0} результатов, показано {1} · Доступность зависит от устройства
unit_tv	个频道	channels	チャンネル	개 채널	canales	chaînes	Kanäle	каналов
unit_radio	座电台	stations	ラジオ局	개 방송국	emisoras	stations	Sender	станций
unit_short_tv	个	channels	ch	개	can.	ch.	Kan.	кан.
unit_short_radio	座	stations	局	개	emis.	stat.	Snd.	ст.
origin_ok	实时目录	Live directory	最新ディレクトリ	실시간 목록	Directorio en vivo	Répertoire en direct	Live-Verzeichnis	Актуальный каталог
origin_cache	本地缓存	Local cache	ローカルキャッシュ	로컬 캐시	Caché local	Cache local	Lokaler Cache	Локальный кэш
origin_demo	演示数据	Demo data	デモデータ	데모 데이터	Datos de demo	Données de démo	Demodaten	Демоданные
origin_pending	演示数据（待同步）	Demo data (sync pending)	デモデータ（同期待ち）	데모 데이터 (동기화 대기)	Datos de demo (sin sincronizar)	Données de démo (sync. en attente)	Demodaten (Sync ausstehend)	Демоданные (ожидание)
origin_error	离线 / 演示数据	Offline / demo	オフライン / デモ	오프라인 / 데모	Sin conexión / demo	Hors ligne / démo	Offline / Demo	Офлайн / демо
origin_loading	正在同步	Syncing	同期中	동기화 중	Sincronizando	Synchronisation	Synchronisierung	Синхронизация
suffix_cache	（本地缓存）	 (cached)	（キャッシュ）	(캐시)	 (en caché)	 (en cache)	 (zwischengespeichert)	 (кэш)
suffix_demo	（演示数据）	 (demo)	（デモ）	(데모)	 (demo)	 (démo)	 (Demo)	 (демо)
suffix_error	（离线）	 (offline)	（オフライン）	(오프라인)	 (sin conexión)	 (hors ligne)	 (offline)	 (офлайн)
globe_count_fmt	共 {0} {1} · 全球{2}	{0} {1} worldwide{2}	世界の {1} 合計 {0} 件{2}	전 세계 {1} 총 {0}개{2}	{0} {1} en todo el mundo{2}	{0} {1} dans le monde{2}	{0} {1} weltweit{2}	{0} {1} по всему миру{2}
st_loading	{0}目录加载中…	Loading {0} directory…	{0}ディレクトリを読み込み中…	{0} 목록 불러오는 중…	Cargando directorio de {0}…	Chargement du répertoire {0}…	{0}-Verzeichnis wird geladen…	Загрузка каталога {0}…
st_synced	· 已同步	· Synced	· 同期済み	· 동기화됨	· Sincronizado	· Synchronisé	· Synchronisiert	· Синхронизировано
st_loaded	· 已载入 	· Loaded 	· 読み込み 	· 불러옴 	· Cargados 	· Chargés 	· Geladen 	· Загружено 
st_failed	{0}加载失败：	{0} failed:	{0}の読み込み失敗：	{0} 불러오기 실패:	Error de {0}:	Échec de {0} :	{0} fehlgeschlagen:	Ошибка {0}:
st_retry	· 点此重试	· Click to retry	· クリックで再試行	· 눌러서 다시 시도	· Clic para reintentar	· Cliquer pour réessayer	· Klicken zum Wiederholen	· Нажмите для повтора
st_demo	正在使用内置演示数据	Using built-in demo data	内蔵デモデータを使用中	내장 데모 데이터 사용 중	Usando datos de demostración	Données de démo intégrées utilisées	Eingebaute Demodaten werden verwendet	Используются встроенные демоданные
st_pending	等待同步{0}目录…	Waiting to sync {0}…	{0}の同期を待機中…	{0} 동기화 대기 중…	Esperando sincronizar {0}…	En attente de sync {0}…	Warten auf {0}-Sync…	Ожидание синхронизации {0}…
st_ready	准备数据…	Preparing data…	データを準備中…	데이터 준비 중…	Preparando datos…	Préparation des données…	Daten werden vorbereitet…	Подготовка данных…
st_line_ok	{0}：共 {1} 条 · 已载入 {2} 条	{0}: {1} total · {2} loaded	{0}：合計 {1} 件 · 読み込み {2} 件	{0}: 총 {1}개 · 불러옴 {2}개	{0}: {1} en total · {2} cargados	{0} : {1} au total · {2} chargés	{0}: {1} gesamt · {2} geladen	{0}: всего {1} · загружено {2}
st_line_cache	{0}：共 {1} 条 · 本地缓存 {2} 条	{0}: {1} total · {2} cached	{0}：合計 {1} 件 · キャッシュ {2} 件	{0}: 총 {1}개 · 캐시 {2}개	{0}: {1} en total · {2} en caché	{0} : {1} au total · {2} en cache	{0}: {1} gesamt · {2} im Cache	{0}: всего {1} · в кэше {2}
st_line_loading	{0}：正在拉取…	{0}: fetching…	{0}：取得中…	{0}: 불러오는 중…	{0}: descargando…	{0} : récupération…	{0}: wird geladen…	{0}: загрузка…
st_line_error	{0}：失败（{1}）	{0}: failed ({1})	{0}：失敗（{1}）	{0}: 실패 ({1})	{0}: error ({1})	{0} : échec ({1})	{0}: fehlgeschlagen ({1})	{0}: ошибка ({1})
st_line_demo	{0}：内置演示数据	{0}: built-in demo data	{0}：内蔵デモデータ	{0}: 내장 데모 데이터	{0}: datos de demo	{0} : données de démo	{0}: Demodaten	{0}: демоданные
st_line_pending	{0}：等待同步（当前显示演示数据）	{0}: sync pending (showing demo)	{0}：同期待ち（デモを表示）	{0}: 동기화 대기 (데모 표시)	{0}: sync pendiente (demo)	{0} : sync. en attente (démo)	{0}: Sync ausstehend (Demo)	{0}: ожидание (демо)
st_line_idle	{0}：未加载	{0}: not loaded	{0}：未読み込み	{0}: 불러오지 않음	{0}: sin cargar	{0} : non chargé	{0}: nicht geladen	{0}: не загружено
name_tv	电视	TV	テレビ	TV	TV	TV	TV	ТВ
name_radio	电台	Radio	ラジオ	라디오	Radio	Radio	Radio	Радио
player_connecting_title	正在连接…	Connecting…	接続中…	연결 중…	Conectando…	Connexion…	Verbinde…	Подключение…
player_connecting_sub	点击频道即自动播放	Your channel starts automatically	チャンネルをタップすると自動再生	채널을 누르면 자동 재생	La emisora se reproduce automáticamente	La lecture démarre automatiquement	Der Kanal startet automatisch	Канал запустится автоматически
player_no_src	暂无播放源	No stream sources	再生ソースがありません	재생 소스가 없습니다	Sin fuentes de emisión	Aucune source de flux	Keine Stream-Quellen	Нет источников потока
player_no_src_sub	请刷新目录或换一个频道。	Refresh the directory or pick another channel.	ディレクトリを更新するか別のチャンネルを選んでください。	목록을 새로고침하거나 다른 채널을 선택하세요.	Actualiza el directorio o elige otro canal.	Actualisez le répertoire ou choisissez une autre chaîne.	Verzeichnis aktualisieren oder anderen Kanal wählen.	Обновите каталог или выберите другой канал.
player_next_src	换一个源 ↻	Switch source ↻	別のソース ↻	다른 소스 ↻	Cambiar fuente ↻	Changer de source ↻	Quelle wechseln ↻	Сменить источник ↻
player_play_btn	▶ 点击播放	▶ Tap to play	▶ タップで再生	▶ 눌러서 재생	▶ Toca para reproducir	▶ Toucher pour lire	▶ Tippen zum Abspielen	▶ Нажмите для воспроизведения
src_no_fmt	源 {0} / {1}	Source {0} / {1}	ソース {0} / {1}	소스 {0} / {1}	Fuente {0} / {1}	Source {0} / {1}	Quelle {0} / {1}	Источник {0} / {1}
state_connecting	连接中…	Connecting…	接続中…	연결 중…	Conectando…	Connexion…	Verbinde…	Подключение…
state_playing	播放中	Playing	再生中	재생 중	Reproduciendo	Lecture en cours	Wiedergabe	Воспроизведение
state_switch	自动换源…	Switching source…	ソースを切替中…	소스 전환 중…	Cambiando fuente…	Changement de source…	Quellenwechsel…	Смена источника…
state_failed	无法播放	Playback failed	再生できません	재생 실패	No se puede reproducir	Lecture impossible	Wiedergabe fehlgeschlagen	Воспроизведение недоступно
state_manual	点一下播放	Tap to play	タップで再生	눌러서 재생	Toca para reproducir	Toucher pour lire	Tippen zum Abspielen	Нажмите для воспроизведения
state_none	无可用源	No sources	ソースなし	소스 없음	Sin fuentes	Aucune source	Keine Quellen	Нет источников
note_mixed	⚠ 这条是 http:// 源，HTTPS 页面会被浏览器拦截；请改用 https:// 源或点「换一个源」。	⚠ This is an http:// stream, blocked on HTTPS pages. Pick an https:// source or tap Switch source.	~	~	~	~	~	~
note_fail	所有源都连不上：可能是源已失效、需要特定 User-Agent、无 CORS 头或受地域限制。用本地 http 服务打开、或换一个频道试试。	None of the sources worked: the stream may be dead, require a specific User-Agent, lack CORS headers or be geo-blocked. Try a local http server or another channel.	~	~	~	~	~	~
fav_add	收藏	Favourite	お気に入り	즐겨찾기	Favorito	Favori	Favorit	В избранное
fav_del	已收藏	Saved	保存済み	저장됨	Guardado	Enregistré	Gespeichert	Сохранено
fav_tip_add	收藏这个频道	Save this channel	このチャンネルを保存	이 채널 저장	Guardar este canal	Enregistrer cette chaîne	Diesen Kanal speichern	Сохранить канал
fav_tip_del	取消收藏	Remove from favourites	お気に入りから削除	즐겨찾기에서 제거	Quitar de favoritos	Retirer des favoris	Aus Favoriten entfernen	Убрать из избранного
set_badge	数据	DATA	データ	데이터	DATOS	DONNÉES	DATEN	ДАННЫЕ
set_title	数据源设置	Settings & data sources	設定とデータソース	설정 및 데이터 소스	Ajustes y fuentes	Paramètres et sources	Einstellungen & Quellen	Настройки и источники
set_sub	两个公开目录，浏览器直连，不经过本站服务器	Two public directories, fetched directly by your browser	2 つの公開ディレクトリ、ブラウザから直接取得	두 개의 공개 목록, 브라우저에서 직접 연결	Dos directorios públicos, conexión directa del navegador	Deux répertoires publics, chargés directement par le navigateur	Zwei öffentliche Verzeichnisse, direkt vom Browser geladen	Два открытых каталога, загружаемых напрямую браузером
set_intro	电视目录来自 <b>iptv-org</b> 的完整 M3U 播放列表；电台目录优先走 <b>Radio Browser 官方 API</b>，连不上时回落到 <b>BeeZcoming/global-radio</b> 的按地区静态 JSON。<br />两者都是公开、免费、社区维护的源，本站不托管、不转播、不存储任何音视频内容。	TV listings come from the full <b>iptv-org</b> M3U playlist; radio listings prefer the <b>Radio Browser official API</b> and fall back to <b>BeeZcoming/global-radio</b> regional JSON files.<br />Both are public, free, community-maintained directories. This site hosts, relays and stores no audio or video.	~	~	~	~	~	~
set_lbl_lang	界面语言	Interface language	表示言語	인터페이스 언어	Idioma de la interfaz	Langue de l'interface	Oberflächensprache	Язык интерфейса
set_tip_lang	切换后整站文案、国家名与频道分类会同步翻译；选择会保存在本机浏览器。	Switching translates the whole UI, country names and channel categories. Your choice is saved in this browser.	~	~	~	~	~	~
set_lbl_iptv	电视播放列表（IPTV 源）	TV playlist (IPTV source)	テレビ再生リスト（IPTV）	TV 재생목록 (IPTV)	Lista TV (fuente IPTV)	Liste TV (source IPTV)	TV-Playlist (IPTV-Quelle)	TV-плейлист (IPTV)
set_tip_iptv	默认 https://iptv-org.github.io/iptv/index.m3u （约 2.6 MB，含上万个频道；同一频道的多个清晰度会自动合并为多播放源）。也可填任意公开 M3U 地址，或点右上角「导入 M3U」用本地文件。	Defaults to https://iptv-org.github.io/iptv/index.m3u (~2.6 MB, tens of thousands of channels; multiple qualities of one channel are merged into separate sources). Any public M3U URL works, or use Import M3U for a local file.	~	~	~	~	~	~
set_lbl_radio	电台数据目录（global-radio / data）	Radio data directory (global-radio / data)	ラジオデータディレクトリ	라디오 데이터 디렉터리	Directorio de datos de radio	Répertoire de données radio	Radio-Datenverzeichnis	Каталог данных радио
set_tip_radio	仅「静态库」模式使用。填 GitHub data 目录地址即可，程序会自动换成可下载直链，依次尝试 <b>jsDelivr GH CDN → fastly.jsdelivr → raw.githubusercontent → GitHub Pages</b>，并行读取 6 个地区 JSON（跳过重复的 americas 和 25 MB 的 curated 全集），谁先返回就先显示哪批。	Used only in Static mode. Point it at a GitHub data directory; the app resolves it to downloadable URLs via <b>jsDelivr GH CDN → fastly.jsdelivr → raw.githubusercontent → GitHub Pages</b>, fetching 6 regional JSON files in parallel (skipping the duplicate americas and the 25 MB curated set). Each batch appears as soon as it arrives.	~	~	~	~	~	~
set_lbl_limit	最多保留电台数	Maximum stations to keep	保持するラジオ局数の上限	유지할 최대 방송국 수	Máximo de emisoras	Nombre max. de stations	Max. Anzahl Sender	Макс. станций
set_tip_limit	只影响列表里可浏览的条数，<b>不影响显示的总数量</b>。目录总量始终单独统计并展示；按票数 / 点击量排序后只保留热度最高的一部分，避免几万条卡顿。	Only affects how many stations are browsable, <b>not the displayed total</b>. The directory total is counted separately; only the most popular stations are kept to avoid lag.	~	~	~	~	~	~
set_st_tv	电视目录	TV directory	テレビディレクトリ	TV 목록	Directorio TV	Répertoire TV	TV-Verzeichnis	Каталог ТВ
set_st_radio	电台目录	Radio directory	ラジオディレクトリ	라디오 목록	Directorio radio	Répertoire radio	Radio-Verzeichnis	Каталог радио
set_lbl_mode	电台加载方式	Radio loading mode	ラジオ読み込み方式	라디오 불러오기 방식	Modo de carga de radio	Mode de chargement radio	Radio-Lademodus	Режим загрузки радио
set_opt_auto	自动（优先官方 API，不通则用静态库）	Auto (official API first, static fallback)	自動（公式 API 優先、不可なら静的ライブラリ）	자동 (공식 API 우선, 실패 시 정적 라이브러리)	Auto (API oficial primero, respaldo estático)	Auto (API officielle d'abord, repli statique)	Auto (offizielle API zuerst, statisches Fallback)	Авто (сначала API, затем статический каталог)
set_opt_api	只用 Radio Browser 官方 API	Official Radio Browser API only	Radio Browser 公式 API のみ	Radio Browser 공식 API만	Solo API oficial de Radio Browser	API officielle Radio Browser uniquement	Nur offizielle Radio Browser API	Только официальный API Radio Browser
set_opt_static	只用 global-radio 静态 JSON 库	global-radio static JSON only	global-radio 静的 JSON のみ	global-radio 정적 JSON만	Solo JSON estático de global-radio	JSON statique global-radio uniquement	Nur statisches global-radio JSON	Только статический JSON global-radio
set_tip_mode	官方 API 支持服务端 <code>limit / order / hidebroken</code>，只传需要的几千条，比下载整套 24 MB 地区文件更快；「自动」会先用 <code>/json/stats</code> 探测节点，能用就走 API，连不上立刻回落到静态库。总数量取自 API 的 <code>/json/stats</code> 或静态库去重后的全集数，与这里保留的浏览条数无关。	The official API supports server-side <code>limit / order / hidebroken</code>, transferring only a few thousand records instead of the full 24 MB regional files. Auto probes <code>/json/stats</code> first and falls back immediately if unreachable. The displayed total comes from <code>/json/stats</code> or the deduplicated static set, independent of how many stations are kept.	~	~	~	~	~	~
opt_1000	1000 条（最快）	1,000 (fastest)	1,000 件（最速）	1,000개 (가장 빠름)	1.000 (más rápido)	1 000 (rapide)	1.000 (schnellste)	1 000 (быстрее)
opt_2000	2000 条	2,000	2,000 件	2,000개	2.000	2 000	2.000	2 000
opt_5000	5000 条（推荐）	5,000 (recommended)	5,000 件（推奨）	5,000개 (권장)	5.000 (recomendado)	5 000 (recommandé)	5.000 (empfohlen)	5 000 (рекомендуется)
opt_10000	10000 条	10,000	10,000 件	10,000개	10.000	10 000	10.000	10 000
set_save	保存并刷新	Save & refresh	保存して更新	저장 후 새로고침	Guardar y actualizar	Enregistrer et actualiser	Speichern & aktualisieren	Сохранить и обновить
set_clear	清空本地缓存	Clear local cache	ローカルキャッシュを消去	로컬 캐시 지우기	Borrar caché local	Vider le cache local	Lokalen Cache leeren	Очистить локальный кэш
set_default	恢复默认	Restore defaults	初期設定に戻す	기본값 복원	Restaurar valores	Rétablir les valeurs	Standard wiederherstellen	Сбросить настройки
set_note	<b>站点：</b>本页已拆分为 <code>index.html</code> + <code>style.css</code> + <code>app.js</code> + <code>hls.min.js</code>，频道目录由浏览器直连 iptv-org 与 Radio Browser 公开目录获取，站点不存储、不转播任何音视频。<br /><b>反馈服务：</b>本站通过 Git 集成部署，Cloudflare 会自动编译根目录 <code>functions/api/feedback.js</code>；在项目 Settings 绑定 <code>FEEDBACK</code> KV、设置 <code>ADMIN_TOKEN</code> 密钥并重新部署后，反馈会真正写入后台，管理员可在反馈面板读取和导出。<br /><b>HTTPS 说明：</b>Cloudflare 全程 HTTPS，<code>http://</code> 的直播源会被浏览器按「混合内容」拦截，可播频道比本地 http 环境少；优先选 <code>https://</code> 源，或点「换一个源」。部分源还需要特定 User-Agent、受地域限制或无 CORS 头，浏览器无法直连——这是源本身的限制。请只用你有权访问的公开流。	<b>Site:</b> split into <code>index.html</code> + <code>style.css</code> + <code>app.js</code> + <code>hls.min.js</code>. Channel data is fetched by your browser directly from the public iptv-org and Radio Browser directories.<br /><b>Feedback:</b> deployed through Git integration, so Cloudflare compiles the root <code>functions/api/feedback.js</code>. Bind <code>FEEDBACK</code> KV and set the <code>ADMIN_TOKEN</code> secret, then redeploy, to store submissions server-side.<br /><b>About HTTPS:</b> HTTPS-only, so <code>http://</code> streams are blocked as mixed content. Prefer <code>https://</code> sources or tap Switch source. Only use streams you are allowed to access.	~	~	~	~	~	~
toast_radio_static	电台目录共 {0} 座（静态库{1}）	{0} stations in total (static library{1})	~	~	~	~	~	~
toast_static_failed	，{0} 个地区未读到	, {0} regions unavailable	~	~	~	~	~	~
toast_radio_api	电台目录共 {0} 座 · 官方 API 已载入 {1} 座	{0} stations total · {1} loaded via official API	~	~	~	~	~	~
toast_api_fallback	官方 API 取列表失败，自动改用静态 JSON 库	Official API failed; falling back to static JSON library	~	~	~	~	~	~
toast_tv_updated	电视目录已更新：{0} 个频道	TV directory updated: {0} channels	~	~	~	~	~	~
toast_api_down	官方 API 不可达，请改用自动或静态库	Official API unreachable; use Auto or Static instead	~	~	~	~	~	~
toast_all_static_fail	所有地区文件都无法读取	All regional files could not be read	~	~	~	~	~	~
toast_copied	{0}已复制到剪贴板	{0} copied to clipboard	~	~	~	~	~	~
toast_copy_fail	复制失败，请手动选中文本	Copy failed, please select the text manually	~	~	~	~	~	~
toast_downloaded	已下载 {0}	Downloaded {0}	~	~	~	~	~	~
toast_fav_add	已收藏：{0}	Saved: {0}	~	~	~	~	~	~
toast_fav_del	已取消收藏：{0}	Removed: {0}	~	~	~	~	~	~
toast_country	已选 {0} {1} · {2} 条	Selected {0} {1} · {2} entries	~	~	~	~	~	~
toast_reset	筛选已重置	Filters reset	~	~	~	~	~	~
toast_fav_on	仅显示收藏	Showing favourites only	~	~	~	~	~	~
toast_fav_off	显示全部	Showing all	~	~	~	~	~	~
toast_import_empty	文件里没有解析到流地址	No stream URLs found in the file	~	~	~	~	~	~
toast_import_ok	已导入 {0} 个频道（来自 {1}）	Imported {0} channels from {1}	~	~	~	~	~	~
toast_no_result	当前筛选没有结果，先重置筛选	No results under current filters, reset them first	~	~	~	~	~	~
toast_no_channel	当前没有可浏览的频道	No channels available to browse	~	~	~	~	~	~
toast_saved	配置已保存，正在刷新目录	Settings saved, refreshing directory	~	~	~	~	~	~
toast_default	已恢复默认设置	Defaults restored	~	~	~	~	~	~
toast_clear	本地缓存已清空，刷新页面后重新拉取	Local cache cleared; reload to fetch again	~	~	~	~	~	~
toast_switch_src	该源无法播放，自动切换下一个…	This source failed, switching to the next…	~	~	~	~	~	~
toast_lang	界面语言已切换为 {0}	Interface language set to {0}	~	~	~	~	~	~
toast_map_all	已显示全部频道列表	Showing the full channel list	~	~	~	~	~	~
lbl_total	共	Total	合計	총	Total	Total	Gesamt	Всего
lbl_loaded	已载入	Loaded	読み込み	불러옴	Cargados	Chargés	Geladen	Загружено
lbl_synced	已同步	Synced	同期済み	동기화됨	Sincronizado	Synchronisé	Synchronisiert	Синхронизировано
lbl_worldwide	· 全球	· Worldwide	· 世界	· 전 세계	· En todo el mundo	· Dans le monde	· Weltweit	· По всему миру
seo_title_tv	全球电视直播频道目录 · 在线观看 | 公共电视	Live TV Channels Worldwide · Watch Online | Public TV	世界のテレビ生放送チャンネル一覧 | 公共テレビ	전 세계 TV 생중계 채널 목록 | 공공 TV	Canales de TV en directo de todo el mundo | TV Pública	Chaînes TV en direct du monde entier | Télé Publique	Live-TV-Kanäle weltweit | Öffentliches TV	Телеканалы мира в прямом эфире | Общественное ТВ
seo_title_radio	全球网络电台目录 · 在线收听 | 公共电视	Internet Radio Stations Worldwide · Listen Online | Public TV	世界のインターネットラジオ局一覧 | 公共テレビ	전 세계 인터넷 라디오 목록 | 공공 TV	Emisoras de radio web de todo el mundo | TV Pública	Radios web du monde entier | Télé Publique	Webradio-Sender weltweit | Öffentliches TV	Интернет-радиостанции мира | Общественное ТВ
seo_desc_tv	免费在线浏览全球电视直播频道目录，按国家、分类、语言检索，支持 HLS 直接播放、频道收藏与 M3U 播放列表导入导出。数据来自 iptv-org 公开列表，无需注册。	Browse live TV channels worldwide by country, category and language. Play HLS streams, save favourites, import and export M3U playlists. Data from the public iptv-org list, no sign-up.	~	~	~	~	~	~
seo_desc_radio	免费在线收听全球网络电台，按国家、标签、语言检索，支持一键播放、频道收藏与 M3U 导出。数据来自 Radio Browser 公开目录，无需注册。	Listen to internet radio worldwide by country, tag and language. One-tap playback, favourites and M3U export. Data from the public Radio Browser directory, no sign-up.	~	~	~	~	~	~
seo_title	全球电视直播与网络电台目录 · 在线观看收听 | 公共电视	Live TV & Internet Radio Directory · Watch and Listen Online | Public TV	~	~	~	~	~	~
seo_desc	免费在线浏览全球电视直播频道与网络电台目录。按国家、分类、语言检索，支持 HLS 直接播放、频道收藏、M3U 播放列表导入与导出。数据来自 iptv-org 与 Radio Browser 公开目录，无需注册。	Browse live TV channels and internet radio stations worldwide by country, category and language. Play HLS streams, save favourites, import and export M3U playlists. Powered by the public iptv-org and Radio Browser directories, no sign-up.	~	~	~	~	~	~
err_timeout	请求超时	Request timed out	リクエストがタイムアウト	요청 시간 초과	Tiempo de espera agotado	Délai dépassé	Zeitüberschreitung	Время ожидания истекло
err_generic	网络错误	Network error	ネットワークエラー	네트워크 오류	Error de red	Erreur réseau	Netzwerkfehler	Сетевая ошибка
err_network	网络不可达或被跨域拦截	Network unreachable or blocked by CORS	ネットワークに到達できないか CORS でブロック	네트워크에 연결할 수 없거나 CORS로 차단됨	Red inaccesible o bloqueada por CORS	Réseau inaccessible ou bloqué par CORS	Netzwerk nicht erreichbar oder durch CORS blockiert	Сеть недоступна или заблокирована CORS
err_http	HTTP 状态 {0}	HTTP status {0}	HTTP ステータス {0}	HTTP 상태 {0}	Estado HTTP {0}	Statut HTTP {0}	HTTP-Status {0}	HTTP {0}
via_api	官方 API	Official API	公式 API	공식 API	API oficial	API officielle	Offizielle API	Официальный API
via_static	静态 JSON 库	Static JSON library	静的 JSON ライブラリ	정적 JSON 라이브러리	Biblioteca JSON estática	Bibliothèque JSON statique	Statische JSON-Bibliothek	Статический JSON-каталог
via_iptv	iptv-org M3U	iptv-org M3U	iptv-org M3U	iptv-org M3U	iptv-org M3U	iptv-org M3U	iptv-org M3U	iptv-org M3U
via_local	本地导入	Local import	ローカル読み込み	로컬 가져오기	Importación local	Import local	Lokaler Import	Локальный импорт
nav_feedback	反馈	Feedback	フィードバック	피드백	Comentarios	Retour	Feedback	Обратная связь
fb_btn_tip	提交反馈	Send feedback	フィードバックを送る	피드백 보내기	Enviar comentarios	Envoyer un retour	Feedback senden	Отправить отзыв
fb_title	意见反馈	Send feedback	ご意見・ご報告	의견 보내기	Enviar comentarios	Votre avis	Feedback senden	Обратная связь
fb_sub	告诉我们哪里坏了、想要什么，或哪个源失效了。	Tell us what broke, what you want, or which stream died.	不具合・ご要望・失效した配信元をお知らせください。	문제·제안·끊어진 소스를 알려주세요.	Cuéntanos qué falló, qué quieres o qué fuente murió.	Dites-nous ce qui ne marche pas, ce que vous voulez ou quelle source est morte.	Sag uns, was kaputt ist, was du willst oder welcher Stream tot ist.	Расскажите, что сломалось, чего не хватает или какой поток умер.
fb_type	反馈类型	Type	種別	유형	Tipo	Type	Typ	Тип
fb_opt_bug	播放 / 功能问题	Playback or bug	再生・機能の不具合	재생 / 기능 문제	Problema de reproducción	Lecture ou bug	Wiedergabe oder Fehler	Воспроизведение / ошибка
fb_opt_dead	频道 / 电台源失效	Dead channel or station	チャンネル / 放送局の配信停止	채널 / 방송국 소스 끊김	Canal o emisora caída	Chaîne ou station morte	Kanal oder Sender tot	Мёртвый канал / станция
fb_opt_idea	功能建议	Feature idea	機能の提案	기능 제안	Sugerencia	Idée de fonctionnalité	Funktionswunsch	Идея функции
fb_opt_other	其他	Other	その他	기타	Otro	Autre	Sonstiges	Другое
fb_email	联系邮箱（选填）	Email (optional)	メール（任意）	이메일 (선택)	Correo (opcional)	E-mail (facultatif)	E-Mail (optional)	Почта (необязательно)
fb_email_ph	方便回复时填写	Only if you want a reply	返信が必要な場合のみ	답변을 원할 때만	Solo si quieres respuesta	Seulement pour une réponse	Nur für eine Antwort	Только если нужен ответ
fb_message	详细内容	Message	詳細	내용	Mensaje	Message	Nachricht	Сообщение
fb_msg_ph	描述你遇到的问题，附上频道名或链接会更快定位…	Describe the issue; a channel name or URL helps us find it faster…	問題を説明してください。チャンネル名や URL があると早く特定できます…	문제를 설명해 주세요. 채널명이나 URL이 있으면 더 빨리 찾습니다…	Describe el problema; un nombre de canal o URL ayuda…	Décrivez le problème ; un nom de chaîne ou une URL aide…	Problem beschreiben; Kanalname oder URL hilft…	Опишите проблему; название канала или URL поможет…
fb_submit	发送反馈	Send feedback	送信する	보내기	Enviar	Envoyer	Senden	Отправить
fb_sending	正在发送…	Sending…	送信中…	보내는 중…	Enviando…	Envoi…	Senden…	Отправка…
fb_reset	清空	Clear	クリア	지우기	Limpiar	Effacer	Leeren	Очистить
fb_ok	已收到，谢谢反馈！	Thanks, feedback received.	送信しました。ありがとうございます！	접수되었습니다. 감사합니다!	¡Recibido, gracias!	Merci, retour reçu.	Danke, Feedback angekommen.	Спасибо, отзыв получен!
fb_ok_local	反馈服务未连接，已暂存到本机（可在下方导出）。	Feedback endpoint unavailable; saved in this browser (export below).	~	~	~	~	~	~
fb_fail	发送失败，请稍后重试（内容已保留）。	Could not send, please retry (your text is kept).	~	~	~	~	~	~
fb_short	请至少写 5 个字。	Please write at least 5 characters.	~	~	~	~	~	~
fb_wait	稍等一下再提交。	Please wait a moment before submitting.	~	~	~	~	~	~
fb_ctx	将同时提交：<b>{0}</b> · <b>{1}</b> · 当前频道 <b>{2}</b>	Also included: <b>{0}</b> · <b>{1}</b> · current channel <b>{2}</b>	~	~	~	~	~	~
fb_offline	<b>反馈服务未连接：</b>请确认项目是 <b>Pages → Connect to Git</b> 创建的、Settings → Functions 里已绑定 <code>FEEDBACK</code> KV、已设置 <code>ADMIN_TOKEN</code> 密钥，且改动后重新部署过一次。当前提交只会保存在本机浏览器，可在下方导出 JSON。	<b>Feedback service offline:</b> make sure the project was created via <b>Pages → Connect to Git</b>, the <code>FEEDBACK</code> KV binding and <code>ADMIN_TOKEN</code> secret are set, and the project was redeployed after the change.	~	~	~	~	~	~
fb_admin_title	反馈管理	Feedback inbox	フィードバック管理	피드백 관리	Bandeja de comentarios	Boîte de retours	Feedback-Postfach	Ящик отзывов
fb_admin_tip	填入部署时生成的 ADMIN_TOKEN 可读取全部反馈并导出；未连接服务时只能查看本机暂存。	Enter the ADMIN_TOKEN generated at deploy time to read and export all submissions. Offline mode shows local drafts only.	~	~	~	~	~	~
fb_admin_ph	管理密钥（ADMIN_TOKEN）	Admin token (ADMIN_TOKEN)	~	~	~	~	~	~
fb_admin_load	读取	Load	読み込む	불러오기	Cargar	Charger	Laden	Загрузить
fb_admin_export	导出 JSON	Export JSON	JSON を書き出す	JSON 내보내기	Exportar JSON	Exporter JSON	JSON exportieren	Экспорт JSON
fb_admin_na	反馈服务未连接；纯静态模式下只能导出本机暂存。	Feedback service unavailable; in static mode you can only export local drafts.	~	~	~	~	~	~
fb_admin_denied	管理密钥不正确，或服务端未配置 ADMIN_TOKEN。	Wrong admin token, or ADMIN_TOKEN is not configured on the server.	~	~	~	~	~	~
fb_admin_empty	还没有反馈。	No feedback yet.	~	~	~	~	~	~
fb_admin_count	共 {0} 条，显示最新 {1} 条	{0} total, showing latest {1}	~	~	~	~	~	~
fb_admin_local	本机暂存 {0} 条	{0} saved locally	~	~	~	~	~	~
fb_admin_err	读取失败：{0}	Load failed: {0}	~	~	~	~	~	~
fb_kind_bug	问题	Bug	不具合	문제	Problema	Bug	Fehler	Ошибка
fb_kind_dead	源失效	Dead source	配信停止	소스 끊김	Fuente caída	Source morte	Quelle tot	Мёртвый источник
fb_kind_idea	建议	Idea	提案	제안	Sugerencia	Idée	Wunsch	Идея
fb_kind_other	其他	Other	その他	기타	Otro	Autre	Sonstiges	Другое
toast_fb_sent	反馈已发送，谢谢！	Feedback sent, thanks!	~	~	~	~	~	~
toast_fb_local	反馈已暂存本机	Feedback saved locally	~	~	~	~	~	~
toast_fb_export	已导出 {0} 条反馈	Exported {0} entries	~	~	~	~	~	~
set_st_fb	反馈服务	Feedback service	フィードバックサービス	피드백 서비스	Servicio de comentarios	Service de retours	Feedback-Dienst	Служба отзывов
fb_state_on	已连接（{0}）	Connected ({0})	~	~	~	~	~	~
fb_state_off	未连接：纯静态模式，反馈仅保存在本机	Not connected: static mode, feedback stays in this browser	~	~	~	~	~	~
`;
const I18N = {};
I18N_RAW.trim().split('\n').forEach(line=>{
  const c=line.split('\t'), k=(c[0]||'').trim(); if(!k||/^#/.test(k)) return;
  const row={};
  LANGS.forEach((L,i)=>{ const v=(c[i+1]||'').trim(); row[L.id]=(v&&v!=='~')?v:null; });
  I18N[k]=row;
});
function curLang(){ return LANGS.find(L=>L.id===state.uiLang)||LANGS[0]; }
function t(key){
  const row=I18N[key]; let s;
  if(!row) s=key;
  else s=row[state.uiLang]||row.en||row.zh||key;
  for(let i=1;i<arguments.length;i++) s=s.split('{'+String(i-1)+'}').join(String(arguments[i]));
  return s;
}
function fmtNum(n){ try{ return Number(n||0).toLocaleString(curLang().intl); }catch(e){ return String(n||0); } }
function modeKey(base){ return base+'_'+(isTV()?'tv':'radio'); }

/* ---------- 频道元数据的多语言显示（中文为内部规范值） ---------- */
// 中文规范值 -> 英文原词（惰性构建：映射表在下方定义，需等初始化完成后再访问）
let _zh2en=null;
function zh2en(){
  if(_zh2en) return _zh2en;
  const o={}; const put=(k,v)=>{ const z=String(v); if(z&&!o[z]) o[z]=String(k).toLowerCase(); };
  for(const k in CAT_CN) put(k,CAT_CN[k]);
  for(const k in TAG_CN) put(k,TAG_CN[k]);
  for(const k in LANG_CN) put(k.toLowerCase(),LANG_CN[k]);
  o['未标注']='unknown'; o['未知']='unknown'; o['电台']='radio'; o['本地导入']='imported';
  _zh2en=o; return o;
}
// 常见分类/标签的逐语言译名；未命中回退英文原词
const LEX = {
  general:{ja:'総合',ko:'종합',es:'General',fr:'Général',de:'Allgemein',ru:'Общее'},
  news:{ja:'ニュース',ko:'뉴스',es:'Noticias',fr:'Actualités',de:'Nachrichten',ru:'Новости'},
  sports:{ja:'スポーツ',ko:'스포츠',es:'Deportes',fr:'Sports',de:'Sport',ru:'Спорт'},
  movies:{ja:'映画',ko:'영화',es:'Cine',fr:'Films',de:'Filme',ru:'Фильмы'},
  music:{ja:'音楽',ko:'음악',es:'Música',fr:'Musique',de:'Musik',ru:'Музыка'},
  kids:{ja:'子ども',ko:'어린이',es:'Infantil',fr:'Jeunesse',de:'Kinder',ru:'Детское'},
  entertainment:{ja:'エンタメ',ko:'오락',es:'Entretenimiento',fr:'Divertissement',de:'Unterhaltung',ru:'Развлечения'},
  documentary:{ja:'ドキュメンタリー',ko:'다큐멘터리',es:'Documentales',fr:'Documentaires',de:'Dokumentationen',ru:'Документальные'},
  business:{ja:'ビジネス',ko:'경제',es:'Negocios',fr:'Économie',de:'Wirtschaft',ru:'Бизнес'},
  religious:{ja:'宗教',ko:'종교',es:'Religión',fr:'Religion',de:'Religion',ru:'Религия'},
  education:{ja:'教育',ko:'교육',es:'Educación',fr:'Éducation',de:'Bildung',ru:'Образование'},
  culture:{ja:'文化',ko:'문화',es:'Cultura',fr:'Culture',de:'Kultur',ru:'Культура'},
  lifestyle:{ja:'ライフスタイル',ko:'라이프스타일',es:'Estilo de vida',fr:'Art de vivre',de:'Lifestyle',ru:'Стиль жизни'},
  cooking:{ja:'料理',ko:'요리',es:'Cocina',fr:'Cuisine',de:'Kochen',ru:'Кулинария'},
  series:{ja:'ドラマ',ko:'시리즈',es:'Series',fr:'Séries',de:'Serien',ru:'Сериалы'},
  animation:{ja:'アニメ',ko:'애니메이션',es:'Animación',fr:'Animation',de:'Animation',ru:'Анимация'},
  science:{ja:'科学',ko:'과학',es:'Ciencia',fr:'Science',de:'Wissenschaft',ru:'Наука'},
  travel:{ja:'旅行',ko:'여행',es:'Viajes',fr:'Voyage',de:'Reisen',ru:'Путешествия'},
  auto:{ja:'自動車',ko:'자동차',es:'Automóvil',fr:'Automobile',de:'Auto',ru:'Авто'},
  weather:{ja:'天気',ko:'날씨',es:'Tiempo',fr:'Météo',de:'Wetter',ru:'Погода'},
  technology:{ja:'テクノロジー',ko:'기술',es:'Tecnología',fr:'Technologie',de:'Technik',ru:'Технологии'},
  nature:{ja:'自然',ko:'자연',es:'Naturaleza',fr:'Nature',de:'Natur',ru:'Природа'},
  history:{ja:'歴史',ko:'역사',es:'Historia',fr:'Histoire',de:'Geschichte',ru:'История'},
  other:{ja:'その他',ko:'기타',es:'Otros',fr:'Autres',de:'Sonstige',ru:'Прочее'},
  pop:{ja:'ポップ',ko:'팝',es:'Pop',fr:'Pop',de:'Pop',ru:'Поп'},
  rock:{ja:'ロック',ko:'록',es:'Rock',fr:'Rock',de:'Rock',ru:'Рок'},
  jazz:{ja:'ジャズ',ko:'재즈',es:'Jazz',fr:'Jazz',de:'Jazz',ru:'Джаз'},
  classical:{ja:'クラシック',ko:'클래식',es:'Clásica',fr:'Classique',de:'Klassik',ru:'Классика'},
  talk:{ja:'トーク',ko:'토크',es:'Charlas',fr:'Talk',de:'Talk',ru:'Ток-шоу'},
  electronic:{ja:'エレクトロニック',ko:'일렉트로닉',es:'Electrónica',fr:'Électronique',de:'Elektronisch',ru:'Электроника'},
  dance:{ja:'ダンス',ko:'댄스',es:'Dance',fr:'Dance',de:'Dance',ru:'Танцевальная'},
  classical_music:{ja:'クラシック',ko:'클래식',es:'Clásica',fr:'Classique',de:'Klassik',ru:'Классика'},
  variety:{ja:'バラエティ',ko:'종합',es:'Variedades',fr:'Variétés',de:'Vielfalt',ru:'Разное'},
  public:{ja:'公共放送',ko:'공영 방송',es:'Pública',fr:'Service public',de:'Öffentlich-rechtlich',ru:'Общественное'},
  community:{ja:'コミュニティ',ko:'커뮤니티',es:'Comunitaria',fr:'Associative',de:'Community',ru:'Общинное'},
  news_talk:{ja:'ニュース・トーク',ko:'뉴스·토크',es:'Noticias y charlas',fr:'Info & talk',de:'Nachrichten & Talk',ru:'Новости и ток'},
  radio:{ja:'ラジオ',ko:'라디오',es:'Radio',fr:'Radio',de:'Radio',ru:'Радио'},
  unknown:{ja:'不明',ko:'미지정',es:'Sin especificar',fr:'Non renseigné',de:'Unbekannt',ru:'Не указано'},
  imported:{ja:'ローカル読込',ko:'로컬 가져오기',es:'Importado',fr:'Importé',de:'Importiert',ru:'Импортировано'}
};
const LANG_CODE = {
  '英语':'en','中文':'zh','普通话':'zh','粤语':'yue','西班牙语':'es','法语':'fr','德语':'de',
  '日语':'ja','韩语':'ko','阿拉伯语':'ar','葡萄牙语':'pt','俄语':'ru','意大利语':'it',
  '印地语':'hi','荷兰语':'nl','瑞典语':'sv','挪威语':'no','丹麦语':'da','芬兰语':'fi',
  '波兰语':'pl','土耳其语':'tr','希腊语':'el','希伯来语':'he','泰语':'th','越南语':'vi',
  '印尼语':'id','马来语':'ms','菲律宾语':'fil','泰米尔语':'ta','孟加拉语':'bn','乌尔都语':'ur',
  '波斯语':'fa','乌克兰语':'uk','罗马尼亚语':'ro','匈牙利语':'hu','捷克语':'cs',
  '保加利亚语':'bg','克罗地亚语':'hr','塞尔维亚语':'sr','斯洛伐克语':'sk','斯洛文尼亚语':'sl',
  '加泰罗尼亚语':'ca','巴斯克语':'eu','拉丁语':'la','南非荷兰语':'af'
};
let _cn2cc=null;
function cn2cc(){ if(!_cn2cc){ _cn2cc={}; for(const cc in GEO) _cn2cc[GEO[cc][0]]=cc; } return _cn2cc; }
function titleEn(s){ const v=String(s||''); return v?v.charAt(0).toUpperCase()+v.slice(1):v; }
function dispLex(v){
  if(state.uiLang==='zh'||!v) return v;
  const en=zh2en()[v]||''; if(!en) return v;
  return (LEX[en]&&LEX[en][state.uiLang])||titleEn(en);
}
function dispLang(v){
  if(state.uiLang==='zh'||!v) return v;
  const code=LANG_CODE[v];
  if(code&&typeof Intl!=='undefined'&&Intl.DisplayNames){
    try{
      const n=new Intl.DisplayNames([curLang().intl],{type:'language'}).of(code);
      if(n&&n!==code) return n;
    }catch(e){}
  }
  return dispLex(v);
}
function dispCountry(c,cc){
  if(state.uiLang==='zh'||!c) return c;
  let code=cc; if(!code) code=cn2cc()[c];
  if(code&&/^[A-Z]{2}$/.test(code)&&typeof Intl!=='undefined'&&Intl.DisplayNames){
    try{
      const n=new Intl.DisplayNames([curLang().intl],{type:'region'}).of(code);
      if(n&&n!==code) return n;
    }catch(e){}
  }
  return dispLex(c);
}

/* ============================ 中文映射表 ============================ */
// ISO alpha-2 -> [中文名, 纬度, 经度]
const GEO = {
  US:['美国',39.8,-98.6], GB:['英国',54.0,-2.0], CN:['中国',35.0,105.0], HK:['中国香港',22.3,114.2], TW:['中国台湾',23.7,121.0], MO:['中国澳门',22.2,113.5],
  JP:['日本',36.2,138.3], KR:['韩国',36.5,127.9], DE:['德国',51.2,10.4], FR:['法国',46.6,2.2], IT:['意大利',41.9,12.6], ES:['西班牙',40.4,-3.7],
  PT:['葡萄牙',39.4,-8.2], NL:['荷兰',52.1,5.3], BE:['比利时',50.5,4.5], CH:['瑞士',46.8,8.2], AT:['奥地利',47.5,14.6], SE:['瑞典',60.1,18.6],
  NO:['挪威',60.5,8.5], DK:['丹麦',56.0,9.5], FI:['芬兰',61.9,25.7], PL:['波兰',51.9,19.1], CZ:['捷克',49.8,15.5], SK:['斯洛伐克',48.7,19.7],
  HU:['匈牙利',47.2,19.5], RO:['罗马尼亚',45.9,25.0], BG:['保加利亚',42.7,25.5], GR:['希腊',39.1,23.7], HR:['克罗地亚',45.1,15.2], RS:['塞尔维亚',44.0,21.0],
  SI:['斯洛文尼亚',46.2,14.9], BA:['波黑',43.9,18.4], ME:['黑山',42.7,19.4], MK:['北马其顿',41.6,21.7], AL:['阿尔巴尼亚',41.2,20.2], EE:['爱沙尼亚',58.7,25.0],
  LV:['拉脱维亚',56.9,24.6], LT:['立陶宛',55.2,23.9], IE:['爱尔兰',53.4,-8.2], IS:['冰岛',64.9,-19.0], LU:['卢森堡',49.8,6.1], MT:['马耳他',35.9,14.4],
  CY:['塞浦路斯',35.1,33.4], UA:['乌克兰',48.4,31.2], RU:['俄罗斯',61.5,105.3], BY:['白俄罗斯',53.7,27.9], MD:['摩尔多瓦',47.4,28.4], GE:['格鲁吉亚',42.3,43.4],
  AM:['亚美尼亚',40.1,45.0], AZ:['阿塞拜疆',40.1,47.6], TR:['土耳其',39.0,35.2], IL:['以色列',31.0,34.9], PS:['巴勒斯坦',31.9,35.2], SA:['沙特阿拉伯',23.9,45.1],
  AE:['阿联酋',23.4,53.8], QA:['卡塔尔',25.3,51.2], KW:['科威特',29.3,47.5], BH:['巴林',26.0,50.5], OM:['阿曼',20.6,56.1], IQ:['伊拉克',33.2,43.7], IR:['伊朗',32.4,53.7],
  JO:['约旦',30.6,36.2], LB:['黎巴嫩',33.9,35.9], SY:['叙利亚',34.8,38.9], EG:['埃及',26.8,30.8], MA:['摩洛哥',31.8,-7.1], DZ:['阿尔及利亚',28.0,2.6],
  TN:['突尼斯',33.9,9.6], LY:['利比亚',27.0,17.2], SD:['苏丹',15.5,30.2], ET:['埃塞俄比亚',9.1,40.5], KE:['肯尼亚',0.0,37.9], NG:['尼日利亚',9.1,8.7],
  GH:['加纳',7.9,-1.0], SN:['塞内加尔',14.5,-14.5], CI:['科特迪瓦',7.6,-5.5], CM:['喀麦隆',3.8,11.5], ZA:['南非',-29.0,24.7], TZ:['坦桑尼亚',-6.4,34.9],
  UG:['乌干达',1.4,32.3], ZW:['津巴布韦',-19.0,29.9], AO:['安哥拉',-12.3,17.6], MZ:['莫桑比克',-18.7,35.5], IN:['印度',21.0,78.9], PK:['巴基斯坦',30.4,69.3],
  BD:['孟加拉国',23.7,90.4], LK:['斯里兰卡',7.9,80.8], NP:['尼泊尔',28.4,84.1], AF:['阿富汗',33.9,67.7], KZ:['哈萨克斯坦',48.0,66.9], UZ:['乌兹别克斯坦',41.4,64.6],
  MN:['蒙古',46.9,103.8], TH:['泰国',15.9,100.99], VN:['越南',14.1,108.3], PH:['菲律宾',12.9,121.8], MY:['马来西亚',4.2,101.98], SG:['新加坡',1.35,103.8],
  ID:['印度尼西亚',-0.8,113.9], MM:['缅甸',21.9,95.9], KH:['柬埔寨',12.6,104.9], LA:['老挝',19.9,102.5], BN:['文莱',4.5,114.7], AU:['澳大利亚',-25.3,133.8],
  NZ:['新西兰',-40.9,174.9], CA:['加拿大',56.1,-106.3], MX:['墨西哥',23.6,-102.6], BR:['巴西',-14.2,-51.9], AR:['阿根廷',-38.4,-63.6], CL:['智利',-35.7,-71.5],
  CO:['哥伦比亚',4.6,-74.1], PE:['秘鲁',-9.2,-75.0], VE:['委内瑞拉',6.4,-66.6], EC:['厄瓜多尔',-1.8,-78.2], BO:['玻利维亚',-16.3,-64.7], PY:['巴拉圭',-23.4,-58.4],
  UY:['乌拉圭',-32.5,-55.8], CR:['哥斯达黎加',9.9,-84.1], PA:['巴拿马',8.5,-80.8], GT:['危地马拉',15.8,-90.2], CU:['古巴',21.5,-80.0], DO:['多米尼加',18.7,-70.5],
  PR:['波多黎各',18.2,-66.5], JM:['牙买加',18.1,-77.3], TT:['特立尼达和多巴哥',10.5,-61.3], SV:['萨尔瓦多',13.7,-88.9], HN:['洪都拉斯',14.8,-86.6], NI:['尼加拉瓜',12.9,-85.0],
  KY:['开曼群岛',19.3,-81.3], BM:['百慕大',32.3,-64.8], GI:['直布罗陀',36.1,-5.3], MC:['摩纳哥',43.7,7.4], SM:['圣马力诺',43.9,12.5], VA:['梵蒂冈',41.9,12.45],
  LI:['列支敦士登',47.1,9.5], AD:['安道尔',42.5,1.5], XK:['科索沃',42.6,20.9]
};
const CAT_CN = {
  General:'综合', News:'新闻', Sports:'体育', Movies:'电影', Music:'音乐', Kids:'少儿', Entertainment:'娱乐',
  Documentary:'纪录片', Business:'财经', Religious:'宗教', Education:'教育', Culture:'文化', Lifestyle:'生活',
  Cooking:'美食', Series:'剧集', Animation:'动画', Science:'科学', Travel:'旅行', Auto:'汽车', Weather:'天气',
  Shop:'购物', Classic:'经典', Comedy:'喜剧', Family:'家庭', Outdoor:'户外', Legal:'法制', Gaming:'游戏',
  Fashion:'时尚', Health:'健康', Technology:'科技', Nature:'自然', History:'历史', Other:'其他'
};
const LANG_CN = {
  English:'英语', Chinese:'中文', Mandarin:'普通话', Cantonese:'粤语', Spanish:'西班牙语', French:'法语', German:'德语',
  Japanese:'日语', Korean:'韩语', Arabic:'阿拉伯语', Portuguese:'葡萄牙语', Russian:'俄语', Italian:'意大利语',
  Hindi:'印地语', Dutch:'荷兰语', Swedish:'瑞典语', Norwegian:'挪威语', Danish:'丹麦语', Finnish:'芬兰语',
  Polish:'波兰语', Turkish:'土耳其语', Greek:'希腊语', Hebrew:'希伯来语', Thai:'泰语', Vietnamese:'越南语',
  Indonesian:'印尼语', Malay:'马来语', Filipino:'菲律宾语', Tamil:'泰米尔语', Bengali:'孟加拉语', Urdu:'乌尔都语',
  Persian:'波斯语', Ukrainian:'乌克兰语', Romanian:'罗马尼亚语', Hungarian:'匈牙利语', Czech:'捷克语',
  Bulgarian:'保加利亚语', Croatian:'克罗地亚语', Serbian:'塞尔维亚语', Slovak:'斯洛伐克语', Slovenian:'斯洛文尼亚语',
  Catalan:'加泰罗尼亚语', Basque:'巴斯克语', Latin:'拉丁语', afrikaans:'南非荷兰语', german:'德语', english:'英语',
  french:'法语', spanish:'西班牙语', italian:'意大利语', dutch:'荷兰语', polish:'波兰语', russian:'俄语',
  chinese:'中文', japanese:'日语', korean:'韩语', arabic:'阿拉伯语', portuguese:'葡萄牙语', hindi:'印地语'
};
const TAG_CN = {
  pop:'流行', rock:'摇滚', jazz:'爵士', classical:'古典', news:'新闻', talk:'谈话', 'talk radio':'谈话',
  electronic:'电子', dance:'舞曲', hiphop:'嘻哈', hip:'嘻哈', country:'乡村', folk:'民谣', blues:'蓝调',
  soul:'灵魂乐', reggae:'雷鬼', latin:'拉丁', metal:'金属', indie:'独立', alternative:'另类', ambient:'氛围',
  chill:'轻松', lounge:'休闲', trance:'迷幻', house:'浩室', techno:'科技舞曲', oldies:'老歌', '80s':'八十年代',
  '90s':'九十年代', '70s':'七十年代', '60s':'六十年代', hits:'金曲', top40:'热门榜', rnb:'节奏布鲁斯',
  sports:'体育', religion:'宗教', christian:'基督教', islam:'伊斯兰', culture:'文化', community:'社区',
  public:'公共广播', student:'校园', lounge_music:'轻音乐', instrumental:'纯音乐', world:'世界音乐',
  comedy:'喜剧', weather:'天气', traffic:'路况', easy:'轻音乐', variety:'综合', schlager:'民谣流行',
  music:'音乐', songs:'音乐', song:'音乐', radio:'广播', fm:'调频', live:'直播', stream:'直播',
  club:'夜店', edm:'电子舞曲', hop:'嘻哈', kpop:'韩流', jpop:'日流', lofi:'慢摇', chillout:'舒缓',
  religious:'宗教', kids:'少儿', children:'少儿', movie:'电影', movies:'电影', entertainment:'娱乐',
  business:'财经', finance:'财经', documentary:'纪录片', education:'教育', adult:'成人', contemporary:'当代',
  'soft rock':'软摇滚', 'hard rock':'硬摇滚', acoustics:'原声', acoustic:'原声', vocal:'人声'
};
// global-radio 的 tags 是自由文本，统一转小写后再查表
const CAT_LOWER=(function(){const o={};for(const k in CAT_CN)o[k.toLowerCase()]=CAT_CN[k];return o;})();
function catZh(k){
  const low=String(k||'').toLowerCase().trim();
  return TAG_CN[low]||CAT_LOWER[low]||k;
}
const CC_LANG = {
  US:'英语', GB:'英语', AU:'英语', CA:'英语', IE:'英语', NZ:'英语', CN:'中文', HK:'粤语', TW:'中文', SG:'英语',
  JP:'日语', KR:'韩语', DE:'德语', AT:'德语', CH:'德语', FR:'法语', BE:'法语', IT:'意大利语', ES:'西班牙语',
  MX:'西班牙语', AR:'西班牙语', CO:'西班牙语', CL:'西班牙语', PE:'西班牙语', VE:'西班牙语', BR:'葡萄牙语',
  PT:'葡萄牙语', RU:'俄语', UA:'乌克兰语', NL:'荷兰语', SE:'瑞典语', NO:'挪威语', DK:'丹麦语', FI:'芬兰语',
  PL:'波兰语', TR:'土耳其语', GR:'希腊语', IL:'希伯来语', SA:'阿拉伯语', AE:'阿拉伯语', EG:'阿拉伯语',
  IN:'印地语', PK:'乌尔都语', TH:'泰语', VN:'越南语', ID:'印尼语', MY:'马来语', PH:'菲律宾语', CZ:'捷克语',
  RO:'罗马尼亚语', HU:'匈牙利语', BG:'保加利亚语', RS:'塞尔维亚语', HR:'克罗地亚语'
};

/* ============================ 演示数据（降级用） ============================ */
function D(n,c,cc,cat,langs,srcs){const g=GEO[cc]||null;return {n:n,c:c||(g?g[0]:'未知'),cc:cc,cat:cat,l:langs,logo:'',sources:srcs,url:srcs[0],s:srcs.length,lat:g?g[1]:null,lon:g?g[2]:null,f:flag(cc)};}
const DEMO_TV = [
  D('BBC News','英国','GB','新闻',['英语'],['https://stream.example.com/bbc-news.m3u8','https://mirror.example.com/bbc-news.m3u8']),
  D('DW','德国','DE','新闻',['英语','德语'],['https://stream.example.com/dw.m3u8']),
  D('CCTV-13 新闻','中国','CN','新闻',['中文'],['https://stream.example.com/cctv13.m3u8']),
  D('NHK World-Japan','日本','JP','新闻',['英语','日语'],['https://stream.example.com/nhk.m3u8']),
  D('France 24','法国','FR','新闻',['英语','法语'],['https://stream.example.com/f24.m3u8']),
  D('Al Jazeera English','卡塔尔','QA','新闻',['英语','阿拉伯语'],['https://stream.example.com/aje.m3u8']),
  D('CNN International','美国','US','新闻',['英语'],['https://stream.example.com/cnn.m3u8']),
  D('Bloomberg TV','美国','US','财经',['英语'],['https://stream.example.com/bloomberg.m3u8']),
  D('Arirang TV','韩国','KR','新闻',['英语'],['https://stream.example.com/arirang.m3u8']),
  D('CNA International','新加坡','SG','新闻',['英语'],['https://stream.example.com/cna.m3u8']),
  D('Record News','巴西','BR','新闻',['葡萄牙语'],['https://stream.example.com/record.m3u8']),
  D('SABC News','南非','ZA','新闻',['英语'],['https://stream.example.com/sabc.m3u8']),
  D('ABC Australia','澳大利亚','AU','新闻',['英语'],['https://stream.example.com/abc-au.m3u8']),
  D('Trace Urban','法国','FR','音乐',['法语'],['https://stream.example.com/trace.m3u8']),
  D('ZooMoo','新加坡','SG','少儿',['英语'],['https://stream.example.com/zoomoo.m3u8'])
];
const DEMO_RADIO = [
  D('BBC Radio 1','英国','GB','流行',['英语'],['https://stream.example.com/bbcr1.mp3']),
  D('BBC World Service','英国','GB','新闻',['英语'],['https://stream.example.com/bbcws.mp3']),
  D('NPR','美国','US','新闻',['英语'],['https://stream.example.com/npr.mp3']),
  D('KEXP 90.3','美国','US','独立',['英语'],['https://stream.example.com/kexp.mp3']),
  D('France Inter','法国','FR','综合',['法语'],['https://stream.example.com/finter.mp3']),
  D('FIP','法国','FR',' jazz'.trim(),['法语'],['https://stream.example.com/fip.mp3']),
  D('Deutschlandfunk','德国','DE','新闻',['德语'],['https://stream.example.com/dlf.mp3']),
  D('RAI Radio 1','意大利','IT','综合',['意大利语'],['https://stream.example.com/rai1.mp3']),
  D('RNE Radio Nacional','西班牙','ES','新闻',['西班牙语'],['https://stream.example.com/rne.mp3']),
  D('NHK Radio 1','日本','JP','综合',['日语'],['https://stream.example.com/nhk1.mp3']),
  D('ABC Radio National','澳大利亚','AU','新闻',['英语'],['https://stream.example.com/abc-rn.mp3']),
  D('All India Radio','印度','IN','综合',['印地语','英语'],['https://stream.example.com/air.mp3']),
  D('中国之声','中国','CN','新闻',['中文'],['https://stream.example.com/cnr.mp3'])
];

/* ============================ 状态 ============================ */
const state = {
  mode:'tv',
  uiLang:CONF.lang,
  cfg:Object.assign({},CONF),
  data:{tv:[],radio:[]},
  src:{tv:{status:'idle',count:0,total:0,via:'',msg:'',at:0},radio:{status:'idle',count:0,total:0,via:'',msg:'',at:0}},
  q:'',country:'',cat:'',lang:'',favOnly:false,page:1,
  fav:new Set((function(){try{const v=JSON.parse(localStorage.getItem('pip_fav')||'[]');return Array.isArray(v)?v:[];}catch(e){return [];}})()),
  imported:null, rotY:-0.20, rotX:0.20, zoom:1, drag:null,
  current:null, selSrc:0, hls:null, loadToken:0, points:[], pointsDirty:true, hotspots:[], selectedCountry:null
};
const PAGE_SIZE = 40;
const $ = s => document.querySelector(s);
const $$ = s => Array.prototype.slice.call(document.querySelectorAll(s));
const esc = s => String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const data = () => state.imported || state.data[state.mode] || [];
const isTV = () => state.mode==='tv';
function flag(cc){ if(!/^[A-Z]{2}$/.test(cc||'')) return '🌐'; return String.fromCodePoint.apply(null,[...cc].map(c=>127397+c.charCodeAt(0))); }
function zh(k,map){ return map[k] || k; }

function toast(msg){ const t=$('#toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(t._t); t._t=setTimeout(()=>t.classList.remove('show'),3000); }

/* ============================ 配置与缓存 ============================ */
function loadCfg(){
  try{ const o=JSON.parse(localStorage.getItem('pip_cfg')||'{}'); state.cfg=Object.assign({},CONF,o); }catch(e){ state.cfg=Object.assign({},CONF); }
  if(!['auto','api','static'].includes(state.cfg.radioMode)) state.cfg.radioMode=CONF.radioMode;
  if(!LANGS.some(L=>L.id===state.cfg.lang)) state.cfg.lang=CONF.lang;
  state.uiLang=state.cfg.lang;
  $('#cfgIptv').value=state.cfg.iptv; $('#cfgRadio').value=state.cfg.radio;
  $('#cfgLimit').value=String(state.cfg.limit||CONF.limit);
  $('#cfgRadioMode').value=state.cfg.radioMode||CONF.radioMode;
  buildLangOptions();
}
function saveCfg(){
  state.cfg.iptv=$('#cfgIptv').value.trim()||CONF.iptv;
  state.cfg.radio=$('#cfgRadio').value.trim()||CONF.radio;
  state.cfg.radioMode=$('#cfgRadioMode').value||CONF.radioMode;
  state.cfg.limit=parseInt($('#cfgLimit').value,10)||CONF.limit;
  state.cfg.lang=state.uiLang;
  try{ localStorage.setItem('pip_cfg',JSON.stringify(state.cfg)); }catch(e){}
}
/* ---------- 语言切换 ---------- */
function buildLangOptions(){
  $('#cfgLang').innerHTML=LANGS.map(L=>'<option value="'+L.id+'">'+esc(L.label)+'</option>').join('');
  $('#cfgLang').value=state.uiLang;
  $('#langMenu').innerHTML=LANGS.map(L=>
    '<button type="button" role="menuitem" data-lang="'+L.id+'" class="'+(L.id===state.uiLang?'on':'')+'">'+
    '<span>'+esc(L.label)+'</span><span class="code">'+L.code+'</span></button>').join('');
  $('#langName').textContent=curLang().label;
  const tag=$('#brandTag'); if(tag) tag.textContent=curLang().code;
  $('#btnLang').setAttribute('aria-label',t('lang_label'));
}
function applyI18n(){
  $$('[data-i18n],[data-i18n-html],[data-i18n-ph],[data-i18n-title]').forEach(el=>{
    let k=el.dataset.i18n||el.dataset.i18nHtml||el.dataset.i18nPh||el.dataset.i18nTitle;
    if(!k) return;
    if(el.dataset.i18nMode) k=modeKey(k);
    const v=t(k);
    if(el.dataset.i18nHtml!==undefined) el.innerHTML=v;
    else if(el.dataset.i18nPh!==undefined) el.placeholder=v;
    else if(el.dataset.i18nTitle!==undefined) el.title=v;
    else el.textContent=v;
  });
  // 动态按钮：收藏 / 只看收藏 / 播放器状态
  $('#btnOnlyFav').textContent=t(state.favOnly?'btn_fav_on':'btn_fav_off');
  syncFavBtn();
  $('#panelTitle').textContent=t(modeKey('panel_title'));
  $('#panelDesc').textContent=t(modeKey('panel_desc'));
  if($('#feedback')) fbRefreshUI();
  closeLangMenu();
}
function openLangMenu(){
  $('#langMenu').classList.add('show'); $('#btnLang').setAttribute('aria-expanded','true');
  document.body.classList.add('lang-open');
}
function closeLangMenu(){
  $('#langMenu').classList.remove('show'); $('#btnLang').setAttribute('aria-expanded','false');
  document.body.classList.remove('lang-open');
}
function setLang(id){
  if(!LANGS.some(L=>L.id===id)||id===state.uiLang){ closeLangMenu(); return; }
  state.uiLang=id; state.cfg.lang=id;
  try{ localStorage.setItem('pip_cfg',JSON.stringify(state.cfg)); }catch(e){}
  document.documentElement.lang=curLang().html;
  buildLangOptions(); applyI18n(); applySEO();
  fillFilters(); renderList(); renderStatus(); updateGlobeCount(); updateGlobeHint();
  // 播放弹窗若开着，同步静态文案与状态
  if(!$('#modal').classList.contains('hide')){
    $('#mediaPh').innerHTML='<b>'+esc(t('player_connecting_title'))+'</b>'+esc(t('player_connecting_sub'));
    if(state.current){
      $('#mSub').textContent=flag(state.current.cc)+' '+dispCountry(state.current.c,state.current.cc)+' · '+dispLex(state.current.cat)+((state.current.l&&state.current.l.length)?' · '+state.current.l.map(dispLang).join('、'):'');
      playerState(t('state_connecting'));
    }
  }
  toast(t('toast_lang',curLang().label));
}
function slim(items){
  return items.slice(0,Math.max(4000,state.cfg.limit||CONF.limit)).map(x=>({
    n:x.n,c:x.c,cc:x.cc,cat:x.cat,l:(x.l||[]).slice(0,4),logo:x.logo||'',
    sources:(x.sources||[x.url]).slice(0,4),url:x.url,s:x.s,lat:x.lat,lon:x.lon,id:x.id||''
  }));
}
function loadCache(mode){
  try{ const o=JSON.parse(localStorage.getItem('pip_cache_'+mode)||'null'); if(o&&Array.isArray(o.items)&&o.items.length) return o; }catch(e){}
  return null;
}
function saveCache(a,b){
  let mode,items,total,via;
  if(a&&typeof a==='object'){ mode=a.mode;items=a.items;total=a.total;via=a.via; }
  else { mode=a;items=b;total=(items||[]).length;via=''; }
  try{ localStorage.setItem('pip_cache_'+mode,JSON.stringify({at:Date.now(),items:slim(items),total:total,via:via})); }catch(e){}
}

/* ============================ 拉取与解析 ============================ */
async function getText(url,ms){
  ms=ms||25000;
  const ctrl=new AbortController(); const t=setTimeout(()=>ctrl.abort(),ms);
  try{
    const r=await fetch(url,{signal:ctrl.signal,headers:{'Accept':'*/*'},cache:'no-store'});
    if(!r.ok) throw new Error('HTTP '+r.status);
    return await r.text();
  }finally{ clearTimeout(t); }
}
// 把 GitHub 目录页 / CDN / raw / Pages 地址统一成一组可下载的 base
/* ---------- Radio Browser 官方 API（服务端 limit / 排序，传输量远小于整套静态库） ---------- */
let apiNodeHit=null;
function apiCandidates(){
  return apiNodeHit ? [apiNodeHit,...API_NODES.filter(x=>x!==apiNodeHit)] : API_NODES.slice();
}
// 并发探测 /json/stats，谁先返回有效统计就用谁；全部不通则立即放弃，避免拖慢首屏
async function probeApi(){
  const ctrl=new AbortController();
  const timer=setTimeout(()=>ctrl.abort(),2600);
  try{
    // 只对前 3 个节点并发探测，避免给公益服务一次打满 6 个请求；
    // 其余节点仍保留在取列表时的回退链里
    const probes=apiCandidates().slice(0,3);
    return await new Promise((resolve,reject)=>{
      let pending=probes.length,lastErr=null;
      probes.forEach(base=>{
        fetch(base+'/json/stats',{signal:ctrl.signal,cache:'no-store'})
          .then(r=>{ if(!r.ok) throw new Error('HTTP '+r.status); return r.json(); })
          .then(j=>{
            if(!j||typeof j.stations!=='number') throw new Error('Invalid stats payload');
            resolve({base:base,stats:j});
          })
          .catch(e=>{ lastErr=e; if(--pending===0) reject(lastErr||new Error('所有节点不可用')); });
      });
    }).then(w=>{ apiNodeHit=w.base; return w; });
  }catch(e){ return null; }
  finally{ clearTimeout(timer); }
}
async function loadRadioApi(probe){
  const limit=state.cfg.limit||CONF.limit;
  const q='/json/stations?limit='+limit+'&hidebroken=true&order=clickcount&reverse=true';
  const urls=[probe.base,...API_NODES.filter(x=>x!==probe.base)].map(b=>b+q);
  let arr=null,lastErr=null;
  for(const u of urls){
    try{
      const j=JSON.parse(await getText(u,18000));
      if(Array.isArray(j)&&j.length){ arr=j; apiNodeHit=u.replace(q,''); break; }
      lastErr=new Error('返回空列表');
    }catch(e){ lastErr=e; }
  }
  if(!arr) throw lastErr||new Error('官方 API 未返回电台');
  return {items:parseRadioJSON(arr),total:Number(probe.stats.stations)||arr.length,via:'官方 API'};
}

function radioBases(){
  const raw=(state.cfg.radio||CONF.radio).trim().replace(/\/+$/,'');
  const m=raw.match(/github\.com\/([^/]+)\/([^/]+)\/(?:tree|blob)\/([^/]+)\/(.+)$/i);
  if(m){
    const owner=m[1],repo=m[2],branch=m[3],p=m[4].replace(/\/+$/,'');
    return [
      'https://cdn.jsdelivr.net/gh/'+owner+'/'+repo+'@'+branch+'/'+p,
      'https://fastly.jsdelivr.net/gh/'+owner+'/'+repo+'@'+branch+'/'+p,
      'https://raw.githubusercontent.com/'+owner+'/'+repo+'/'+branch+'/'+p,
      'https://'+owner.toLowerCase()+'.github.io/'+repo+'/'+p
    ];
  }
  return [raw];
}
let radioBaseHit=0; // 记住上一个成功的直链，后续文件少走弯路
function radioFileUrls(file){
  const bs=radioBases(), out=[];
  for(let i=0;i<bs.length;i++) out.push(bs[(radioBaseHit+i)%bs.length]+'/'+file);
  return out;
}
async function fetchRadioFile(file){
  const urls=radioFileUrls(file); let lastErr=null;
  for(let i=0;i<urls.length;i++){
    try{
      const txt=await getText(urls[i],22000);
      const j=JSON.parse(txt);
      const arr=Array.isArray(j)?j:(j.stations||[]);
      if(!arr.length) throw new Error('No stations in file');
      radioBaseHit=(radioBaseHit+i)%radioBases().length;
      return parseRadioJSON(arr);
    }catch(e){ lastErr=e; }
  }
  throw lastErr||new Error('所有直链均不可用');
}
function cleanName(n){
  return String(n||'').replace(/\s*\((?:SD|HD|FHD|UHD|4K|8K|\d{3,4}[pi]?|\d+p)\)\s*$/i,'').trim() || String(n||'未命名频道');
}
function langsFrom(s,cc){
  if(!s) return cc&&CC_LANG[cc]?[CC_LANG[cc]]:[];
  return String(s).split(/[;,|]/).map(x=>x.trim()).filter(Boolean).slice(0,4).map(x=>zh(x,LANG_CN));
}
function parseIptvM3U(text){
  const lines=text.split(/\r?\n/); const map=new Map(); let meta=null;
  for(let i=0;i<lines.length;i++){
    const ln=lines[i].trim(); if(!ln) continue;
    if(/^#EXTM3U/i.test(ln)){ continue; }
    if(/^#EXTINF\s*:/i.test(ln)){
      const comma=ln.lastIndexOf(',');
      const rawName=comma>=0?ln.slice(comma+1).trim():'未命名频道';
      const head=comma>=0?ln.slice(0,comma):ln;
      const attr=k=>(head.match(new RegExp(k+'="([^"]*)"','i'))||[])[1]||'';
      const id=attr('tvg-id');
      const grp=attr('group-title')||'General';
      meta={
        name:rawName, clean:cleanName(rawName), id:id,
        logo:attr('tvg-logo'), grp:grp,
        country:attr('tvg-country'), lang:attr('tvg-language')
      };
      continue;
    }
    if(ln[0]==='#') continue; // #EXTVLCOPT / #KODIPROP / #EXTGRP
    if(!/^(https?|rtmp|rtsp|mms|udp):\/\//i.test(ln)){ meta=null; continue; }
    if(!meta) continue;
    const url=ln.split('|')[0].trim();
    const baseId=(meta.id||'').replace(/@.*$/,'');
    let cc=(meta.country||'').toUpperCase();
    if(!/^[A-Z]{2}$/.test(cc)){
      const m=baseId.match(/\.([A-Za-z]{2})$/);
      cc=m?m[1].toUpperCase():'';
    }
    if(cc==='UK') cc='GB';
    const g=GEO[cc]||null;
    const key=(baseId||('n:'+meta.clean)).toLowerCase();
    let ch=map.get(key);
    if(!ch){
      const cats=grpSplit(meta.grp);
      ch={
        n:meta.clean, id:baseId, c:g?g[0]:(cc||'未标注'), cc:cc,
        cat:zh(cats[0],CAT_CN), cats:cats.map(x=>zh(x,CAT_CN)),
        l:langsFrom(meta.lang,cc), logo:meta.logo,
        sources:[], url:url, s:0, lat:g?g[1]:null, lon:g?g[2]:null, f:flag(cc)
      };
      map.set(key,ch);
    }
    if(ch.sources.indexOf(url)<0) ch.sources.push(url);
    meta=null;
  }
  const out=[...map.values()];
  out.forEach(x=>{ x.s=x.sources.length; x.url=x.sources[0]; });
  return out;
  function grpSplit(s){ return String(s||'General').split(';').map(x=>x.trim()).filter(Boolean).slice(0,3); }
}
function parseRadioJSON(arr){
  const out=[];
  for(const x of arr){
    if(!x||!x.name) continue;
    let url=String(x.url_resolved||x.url||'').split('|')[0].trim();
    if(!/^https?:\/\//i.test(url)) continue;
    // http 源的 https 备选在 openChannel 里统一生成，保证原始 https 源优先
    const sources=[url];
    const cc=String(x.countrycode||'').toUpperCase();
    const g=GEO[cc]||null;
    let lat=null,lon=null;
    if(x.geo_lat!==null&&x.geo_lat!==''&&x.geo_lat!==undefined&&!isNaN(Number(x.geo_lat))) lat=Number(x.geo_lat);
    if(x.geo_long!==null&&x.geo_long!==''&&x.geo_long!==undefined&&!isNaN(Number(x.geo_long))) lon=Number(x.geo_long);
    if(lat===null||lon===null){ lat=g?g[1]:null; lon=g?g[2]:null; }
    const tags=String(x.tags||'').split(/[,\s]+/).map(s=>s.trim().toLowerCase()).filter(Boolean).slice(0,3);
    const cats=tags.length?tags:[String(x.codec||'电台').toLowerCase()];
    const langs=String(x.language||'').split(/[,\s]+/).map(s=>s.trim()).filter(Boolean).slice(0,4).map(s=>zh(s,LANG_CN));
    out.push({
      n:String(x.name).trim(), id:x.stationuuid||'', c:g?g[0]:(x.country||'未标注'), cc:cc,
      cat:catZh(cats[0]),
      cats:cats.map(catZh),
      l:langs.length?langs:(cc&&CC_LANG[cc]?[CC_LANG[cc]]:[]),
      logo:x.favicon||'', sources:sources, url:sources[0], s:sources.length,
      lat:lat,lon:lon,f:flag(cc),codec:x.codec||'',bitrate:x.bitrate||0,hls:x.hls||0,
      votes:Number(x.votes)||0, clicks:Number(x.clickcount)||0,
      key:String(x.stationuuid||url).toLowerCase()
    });
  }
  return out;
}
function parseLocalM3U(text,name){
  const items=parseIptvM3U(text);
  if(!items.length) return [];
  items.forEach(x=>{ if(!x.cc) x.c='本地导入'; });
  return items;
}

/* ============================ 数据加载 ============================ */
function commitRadio(items,total,via){
  const s=state.src.radio;
  state.data.radio=items;
  s.status='ok'; s.count=items.length; s.total=total; s.via=via; s.at=Date.now(); s.msg='';
  state.pointsDirty=true;
  saveCache({mode:'radio',items:items,total:total,via:via});
  fillFilters(); renderList(); renderStatus(); updateGlobeCount();
}
// 静态库：累计「去重后的全集」作为总数量，列表只保留热度最高的一部分
async function loadRadioStatic(){
  const limit=state.cfg.limit||CONF.limit;
  const collected=new Map(); let ok=0;
  const apply=items=>{
    for(const x of items) if(!collected.has(x.key)) collected.set(x.key,x);
    const arr=[...collected.values()]
      .sort((a,b)=>(b.votes-a.votes)||(b.clicks-a.clicks))
      .slice(0,limit);
    commitRadio(arr,collected.size,'静态 JSON 库');
  };
  const jobs=RADIO_FILES.map(f=>
    fetchRadioFile(f).then(items=>{ ok++; apply(items); return true; })
                     .catch(()=>false)
  );
  await Promise.all(jobs);
  if(!ok) throw new Error(t('toast_all_static_fail'));
  const failed=RADIO_FILES.length-ok;
  toast(t('toast_radio_static',fmtNum(state.src.radio.total),failed?t('toast_static_failed',failed):''));
}
async function loadRadio(){
  const mode=state.cfg.radioMode||CONF.radioMode;
  const probe=(mode!=='static')?await probeApi():null;
  if(mode==='api'&&!probe) throw new Error(t('toast_api_down'));
  if(probe){
    try{
      const r=await loadRadioApi(probe);
      commitRadio(r.items,r.total,r.via);
      toast(t('toast_radio_api',fmtNum(r.total),fmtNum(r.items.length)));
      return;
    }catch(e){
      if(mode==='api') throw e;
      toast(t('toast_api_fallback'));
    }
  }
  await loadRadioStatic();
}
async function loadData(mode,force){
  const s=state.src[mode];
  if(s.status==='loading') return;
  if(!force && s.status==='ok') return;
  s.status='loading'; s.msg=''; renderStatus();
  try{
    if(mode==='tv'){
      const txt=await getText(state.cfg.iptv,30000);
      const items=parseIptvM3U(txt);
      if(!items.length) throw new Error('No channels parsed from playlist');
      state.data.tv=items;
      saveCache('tv',items);
      s.status='ok'; s.count=items.length; s.total=items.length; s.via='iptv-org M3U'; s.at=Date.now(); s.msg='';
      state.pointsDirty=true;
      toast(t('toast_tv_updated',fmtNum(items.length)));
    }else{
      await loadRadio();
    }
  }catch(e){
    s.status='error';
    let m=(e&&e.name==='AbortError')?t('err_timeout'):((e&&e.message)||t('err_generic'));
    if(/Failed to fetch|NetworkError|Load failed/i.test(m)) m=t('err_network');
    else if(/^HTTP \d+/.test(m)) m=t('err_http',m.replace(/^HTTP\s*/,''));
    s.msg=m; s.at=Date.now();
  }
  fillFilters(); renderList(); renderStatus(); updateGlobeCount();
}
function updateGlobeHint(){
  $('#globeHint').textContent = W<=700 ? t('globe_hint_mobile') : t(modeKey('globe_hint'));
}
// 目录总数量（不是「已载入/保留」的条数）
function srcTotal(s){ return s.total||s.count||0; }
function nameOf(m){ return t(m==='tv'?'name_tv':'name_radio'); }
function unitOf(m){ return t(m==='tv'?'unit_tv':'unit_radio'); }
function originOf(st){
  return ({ok:'origin_ok',cache:'origin_cache',demo:'origin_demo',pending:'origin_pending',error:'origin_error',loading:'origin_loading'})[st]||'origin_ok';
}
function updateGlobeCount(){
  const s=state.src[state.mode], n=srcTotal(s)||data().length;
  const suffix=s.status==='cache'?t('suffix_cache'):(s.status==='demo'||s.status==='pending')?t('suffix_demo'):s.status==='error'?t('suffix_error'):'';
  $('#globeCount').textContent=t('globe_count_fmt',fmtNum(n),unitOf(state.mode),suffix);
  updateGlobeHint();
}
function renderStatus(){
  const s=state.src[state.mode];
  const chip=$('#srcChip'); chip.className='chip';
  const nm=t(isTV()?'name_tv':'name_radio');
  const unit=unitOf(state.mode);
  const total=srcTotal(s);
  const compact=(document.documentElement.clientWidth||window.innerWidth)<=700;
  const shortU=t(isTV()?'unit_short_tv':'unit_short_radio');
  let txt='';
  if(s.status==='loading'){ chip.classList.add('loading'); txt=t('st_loading',nm); }
  else if(s.status==='ok'){
    chip.classList.add('ok');
    txt=compact
      ? nm+' · '+t('lbl_total')+' '+fmtNum(total)+' '+shortU
      : nm+' · '+t('lbl_total')+' '+fmtNum(total)+' '+unit+(s.count<total?' · '+t('lbl_loaded')+' '+fmtNum(s.count)+' '+unit:'')+' · '+t('lbl_synced');
  }
  else if(s.status==='cache'){
    chip.classList.add('ok');
    txt=compact?nm+' · '+t('lbl_total')+' '+fmtNum(total)
               :nm+' · '+t('lbl_total')+' '+fmtNum(total)+' · '+t('origin_cache');
  }
  else if(s.status==='error'){ chip.classList.add('err'); txt=t('st_failed',nm)+s.msg.slice(0,18)+' '+t('st_retry'); }
  else if(s.status==='demo'){ chip.classList.add('err'); txt=t('st_demo'); }
  else if(s.status==='pending'){ chip.classList.add('loading'); txt=t('st_pending',nm); }
  else txt=t('st_ready');
  $('#srcChipText').textContent=txt;
  chip.title=txt+(s.via?' · '+s.via:'');
  const line=m=>{
    const o=state.src[m], n=nameOf(m), tt=fmtNum(srcTotal(o));
    try{
      if(o.status==='ok') return t('st_line_ok',n,tt,fmtNum(o.count))+(o.via?' ('+o.via+')':'')+' · '+new Date(o.at).toLocaleTimeString(curLang().intl,{hour:'2-digit',minute:'2-digit'});
      if(o.status==='cache') return t('st_line_cache',n,tt,fmtNum(o.count));
      if(o.status==='loading') return t('st_line_loading',n);
      if(o.status==='error') return t('st_line_error',n,o.msg);
      if(o.status==='demo') return t('st_line_demo',n);
      if(o.status==='pending') return t('st_line_pending',n);
      return t('st_line_idle',n);
    }catch(e){ return n; }
  };
  $('#stTV').textContent=line('tv'); $('#stRadio').textContent=line('radio');
}

/* ============================ 筛选与列表 ============================ */
function filtered(){
  const q=state.q.trim().toLowerCase();
  const d=data();
  const zh=state.uiLang==='zh';
  return d.filter(ch=>{
    if(state.favOnly && !state.fav.has(ch.n)) return false;
    if(state.country && ch.c!==state.country) return false;
    if(state.cat && !(ch.cats||[ch.cat]).includes(state.cat)) return false;
    if(state.lang && !(ch.l||[]).includes(state.lang)) return false;
    if(q){
      // 规范值 + 当前界面语言的译名都参与匹配，切语言后原关键词仍能搜到
      let hay=[ch.n,ch.c,ch.cc,ch.cat,(ch.cats||[]).join(' '),(ch.l||[]).join(' ')];
      if(!zh) hay=hay.concat([
        dispCountry(ch.c,ch.cc), dispLex(ch.cat),
        (ch.cats||[]).map(dispLex).join(' '), (ch.l||[]).map(dispLang).join(' ')
      ]);
      if(hay.join(' ').toLowerCase().indexOf(q)<0) return false;
    }
    return true;
  });
}
function fillFilters(){
  const d=data(),cs=new Set(),ks=new Set(),ls=new Set();
  for(const x of d){
    cs.add(x.c);
    const c=x.cats||[x.cat]; for(const v of c) ks.add(v);
    const l=x.l||[]; for(const v of l) ls.add(v);
  }
  // 按「当前语言的显示名」排序，value 仍保持中文规范值，切语言不会丢筛选状态
  const locale=curLang().intl;
  const cmp=(a,b,fn)=>String(fn(a)).localeCompare(String(fn(b)),locale);
  const countries=[...cs].sort((a,b)=>cmp(a,b,x=>dispCountry(x,cn2cc()[x])));
  const cats=[...ks].sort((a,b)=>cmp(a,b,dispLex));
  const langs=[...ls].sort((a,b)=>cmp(a,b,dispLang));
  const set=(el,vals,labelKey,keep,fn)=>{
    const v=keep&&vals.includes(keep)?keep:'';
    el.innerHTML='<option value="">'+esc(t(labelKey))+'</option>'+vals.slice(0,300).map(x=>
      '<option value="'+esc(x)+'"'+(x===v?' selected':'')+'>'+esc(fn(x))+'</option>').join('');
    return v;
  };
  state.country=set($('#fCountry'),countries,'f_country',state.country,x=>dispCountry(x,cn2cc()[x]));
  state.cat=set($('#fCat'),cats,'f_cat',state.cat,dispLex);
  state.lang=set($('#fLang'),langs,'f_lang',state.lang,dispLang);
}
function logoHTML(ch){
  const txt=esc(ch.n.replace(/[^A-Za-z0-9\u4e00-\u9fa5]/g,'').slice(0,3)||'◉');
  if(ch.logo && /^https?:\/\//i.test(ch.logo))
    return txt+'<img src="'+esc(ch.logo)+'" alt="" loading="lazy" onerror="this.remove()" />';
  return txt;
}
function renderList(){
  const all=filtered();
  const shown=all.slice(0,state.page*PAGE_SIZE);
  $('#panelDesc').textContent=t(modeKey('panel_desc'));
  $('#panelTitle').textContent=t(modeKey('panel_title'));
  const src=state.src[state.mode];
  const origin=t(originOf(src.status));
  const total=srcTotal(src);
  $('#panelCount').innerHTML=esc(t('panel_count_fmt',fmtNum(total),unitOf(state.mode),origin))+
    ' <span>· '+esc(t('panel_result_fmt',fmtNum(all.length),fmtNum(Math.min(shown.length,all.length))))+'</span>';
  if(!all.length){ $('#list').innerHTML='<div class="empty">'+t('empty')+'</div>'; return; }
  // 几万条时避免每张卡片都做一次线性 indexOf
  const d=data(), pos=new Map(); for(let i=0;i<d.length;i++) if(!pos.has(d[i])) pos.set(d[i],i);
  const html=shown.map(ch=>{
    const on=state.fav.has(ch.n);
    const idx=pos.get(ch);
    const nsrc=ch.sources?ch.sources.length:(ch.s||1);
    return '<div class="card" data-i="'+idx+'">'+
      '<div class="logo">'+logoHTML(ch)+'</div>'+
      '<div class="info"><div class="nm">'+esc(ch.n)+'</div>'+
      '<div class="meta">'+flag(ch.cc)+' '+esc(dispCountry(ch.c,ch.cc))+' · '+esc(dispLex(ch.cat))+
        ((ch.l&&ch.l.length)?' · '+esc(ch.l.map(dispLang).join('、')):'')+'</div></div>'+
      '<span class="src">'+esc(t(nsrc===1?'src_count_one':'src_count',nsrc))+'</span>'+
      '<button class="fav '+(on?'on':'')+'" data-fav="'+esc(ch.n)+'" title="'+esc(t(on?'fav_tip_del':'fav_tip_add'))+'">'+(on?'★':'☆')+'</button>'+
    '</div>';
  }).join('');
  const rest=all.length-shown.length;
  $('#list').innerHTML=html+(rest>0?'<button class="more" id="btnMore">'+esc(t('more'))+' ('+fmtNum(rest)+')</button>':'');
}

/* ============================ 面板 ============================ */
function openPanel(){
  state.page=1; $('#panel').classList.add('show'); $('#scrim').classList.add('show');
  document.body.classList.add('panel-open'); renderList();
  // 手机上不自动聚焦，避免抽屉一升起就弹出软键盘
  setTimeout(()=>{ if((document.documentElement.clientWidth||window.innerWidth)>700) $('#q').focus(); },260);
}
function closePanel(){
  $('#panel').classList.remove('show'); $('#scrim').classList.remove('show');
  document.body.classList.remove('panel-open');
}

/* ============================ 复制 / 导出 ============================ */
function copyText(txt,label){
  const done=()=>toast(t('toast_copied',label));
  if(navigator.clipboard&&window.isSecureContext){ navigator.clipboard.writeText(txt).then(done,fallback); }else fallback();
  function fallback(){
    const ta=document.createElement('textarea'); ta.value=txt; ta.style.position='fixed'; ta.style.opacity='0';
    document.body.appendChild(ta); ta.select();
    try{document.execCommand('copy'); done();}catch(e){toast(t('toast_copy_fail'));}
    document.body.removeChild(ta);
  }
}
function download(name,txt){
  const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([txt],{type:'audio/x-mpegurl;charset=utf-8'}));
  a.download=name; document.body.appendChild(a); a.click();
  setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},300);
  toast(t('toast_downloaded',name));
}
function m3uEntry(ch,i){
  const srcs=ch.sources||[ch.url];
  const u=srcs[i||0]||ch.url||'';
  const id=ch.id||((ch.cc?ch.cc+'.':'')+ch.n.replace(/[^A-Za-z0-9\u4e00-\u9fa5]/g,''));
  return '#EXTINF:-1 tvg-id="'+esc(id)+'" tvg-name="'+esc(ch.n)+'" tvg-logo="'+esc(ch.logo||'')+'" group-title="'+esc(ch.cat||'综合')+'",'+esc(ch.n)+'\n'+u;
}
function m3uFor(list){ return '#EXTM3U\n'+list.map(c=>m3uEntry(c,0)).join('\n')+'\n'; }

/* ============================ 播放弹窗（精简） ============================ */
function syncFavBtn(){
  const ch=state.current,b=$('#btnFav');
  if(!ch||!b) return;
  const on=state.fav.has(ch.n);
  b.classList.toggle('on',on);
  const star=b.querySelector('.star'),tx=b.querySelector('.txt');
  if(star)star.textContent=on?'★':'☆';
  if(tx)tx.textContent=t(on?'fav_del':'fav_add');
  b.setAttribute('aria-label',on?t('fav_tip_del'):t('fav_tip_add'));
  b.title=on?t('fav_tip_del'):t('fav_tip_add');
}
function toggleFav(name){
  const on=state.fav.has(name);
  if(on) state.fav.delete(name); else state.fav.add(name);
  try{ localStorage.setItem('pip_fav',JSON.stringify([...state.fav])); }catch(e){}
  syncFavBtn(); renderList();
  toast(t(on?'toast_fav_del':'toast_fav_add',name));
}
function playerState(txt,color){
  const e=$('#mState'); e.textContent=txt; e.style.color=color||'';
}
function playerNote(html){
  const e=$('#playerNote');
  if(!html){ e.classList.add('hide'); e.innerHTML=''; return; }
  e.innerHTML=html; e.classList.remove('hide');
}
function openChannel(ch){
  state.loadToken++;
  state.current=ch; state.selSrc=0;
  $('#mName').textContent=ch.n;
  $('#mLogo').innerHTML=logoHTML(ch);
  $('#mSub').textContent=flag(ch.cc)+' '+dispCountry(ch.c,ch.cc)+' · '+dispLex(ch.cat)+((ch.l&&ch.l.length)?' · '+ch.l.map(dispLang).join('、'):'');
  // 优先级：原始 HTTPS > 由 HTTP 升级出的 HTTPS > 原始 HTTP
  // 不先去试可能不存在的「升级版」，也不在 HTTPS 页面直接撞上混合内容
  const raw=(ch.sources||[ch.url]).slice(0,12);
  const https=raw.filter(u=>/^https:\/\//i.test(u));
  const http=raw.filter(u=>/^http:\/\//i.test(u));
  const alt=http.map(u=>u.replace(/^http:\/\//i,'https://')).filter(u=>https.indexOf(u)<0);
  const srcs=[...https,...alt,...http];
  state.current._urls=srcs;
  retryLeft=Math.min(4,Math.max(0,srcs.length-1));
  const box=$('#mediaBox');
  box.classList.toggle('audio',!isTV());
  const old=box.querySelector('video,audio'); if(old) old.remove();
  box.querySelectorAll('.play-overlay').forEach(e=>e.remove());
  $('#mediaPh').innerHTML='<b>'+esc(t('player_connecting_title'))+'</b>'+esc(t('player_connecting_sub'));
  $('#mediaPh').classList.remove('hide');
  playerNote('');
  syncFavBtn();
  $('#modal').classList.remove('hide');
  if(srcs.length){ setActiveSrc(0); loadStream(srcs[0]); }
  else{
    $('#mediaPh').innerHTML='<b>'+esc(t('player_no_src'))+'</b>'+esc(t('player_no_src_sub'));
    playerState(t('state_none'),'var(--red)');
  }
}
function closeModal(){
  state.loadToken++;
  $('#modal').classList.add('hide');
  if(state.hls){ state.hls.destroy(); state.hls=null; }
  const box=$('#mediaBox');
  box.querySelectorAll('.play-overlay').forEach(e=>e.remove());
  const m=box.querySelector('video,audio');
  if(m){ m.pause(); m.removeAttribute('src'); m.load(); }
}
let hlsPromise=null, retryLeft=0;
// hls.js 已内嵌在本文件里，正常情况这里直接返回；保留多 CDN 兜底以防内嵌脚本被裁掉
function loadHlsLib(){
  if(window.Hls) return Promise.resolve(true);
  if(hlsPromise) return hlsPromise;
  hlsPromise=new Promise(res=>{
    const cdns=[
      'https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js',
      'https://fastly.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js',
      'https://unpkg.com/hls.js@1.5.17/dist/hls.min.js'
    ];
    let i=0, done=false;
    const fin=v=>{ if(!done){ done=true; res(v); } };
    const next=()=>{
      if(window.Hls) return fin(true);
      if(i>=cdns.length) return fin(false);
      const s=document.createElement('script'); s.src=cdns[i++];
      s.onload=()=>fin(!!window.Hls); s.onerror=next;
      document.head.appendChild(s);
    };
    next(); setTimeout(()=>fin(!!window.Hls),6000);
  });
  return hlsPromise;
}
function showPlayOverlay(m){
  const box=$('#mediaBox');
  if(box.querySelector('.play-overlay')) return;
  const b=document.createElement('button');
  b.type='button'; b.className='play-overlay'; b.textContent=t('player_play_btn');
  b.addEventListener('click',()=>{ b.remove(); m.play().catch(()=>playerState(t('state_manual'),'var(--amber)')); });
  box.appendChild(b);
}
function tryPlay(m){
  try{
    const p=m.play();
    if(p&&p.catch) p.catch(()=>{ if(document.body.contains(m)){ showPlayOverlay(m); playerState(t('state_manual'),'var(--amber)'); } });
  }catch(e){ showPlayOverlay(m); }
}
async function loadStream(url){
  if(!url) return;
  url=url.split('|')[0].trim();
  const token=++state.loadToken;
  const radio=!isTV();
  const mixed=/^http:\/\//i.test(url)&&location.protocol==='https:';
  const box=$('#mediaBox');
  box.querySelectorAll('.play-overlay').forEach(e=>e.remove());
  if(state.hls){ state.hls.destroy(); state.hls=null; }
  const old=box.querySelector('video,audio'); if(old){ old.pause(); old.remove(); }
  $('#mediaPh').classList.add('hide');
  const m=document.createElement(radio?'audio':'video');
  m.controls=true; m.autoplay=true; m.playsInline=true;
  box.appendChild(m);
  const alive=()=>token===state.loadToken&&!$('#modal').classList.contains('hide');
  const isHLS=/\.m3u8(\?|$)/i.test(url)||(state.current&&state.current.hls===1);
  playerState(t('state_connecting'));
  playerNote(mixed?t('note_mixed'):'');
  function streamFailed(msg){
    if(!alive()) return;
    const next=state.selSrc+1;
    if(retryLeft>0&&state.current&&state.current._urls[next]){
      retryLeft--;
      toast(t('toast_switch_src'));
      playerState(t('state_switch'),'var(--amber)');
      setActiveSrc(next);
      loadStream(state.current._urls[next]);
    }else{
      playerState(t('state_failed'),'var(--red)');
      playerNote(t('note_fail'));
    }
  }
  function attachHls(){
    // hls.js 走 fetch 拉分片，需要 CORS；直接 src 播放的 MP3/MP4 不需要
    m.crossOrigin='anonymous';
    state.hls=new Hls({enableWorker:true,lowLatencyMode:true});
    state.hls.loadSource(url); state.hls.attachMedia(m);
    state.hls.on(Hls.Events.MANIFEST_PARSED,()=>{ if(alive()) tryPlay(m); });
    state.hls.on(Hls.Events.ERROR,(_,d)=>{ if(d.fatal) streamFailed(); });
  }
  // hls.js 内嵌就绪 → 同步路径，保住点击频道这次用户手势
  if(isHLS&&window.Hls&&Hls.isSupported()){
    attachHls();
  }else if(isHLS&&!window.Hls&&m.canPlayType('application/vnd.apple.mpegurl')){
    m.src=url; tryPlay(m);
  }else if(isHLS){
    const ok=await loadHlsLib();
    if(!alive()) return;
    if(ok&&window.Hls&&Hls.isSupported()) attachHls();
    else{
      // 不把路堵死：再试一次浏览器直连，失败就自动换源
      m.src=url; tryPlay(m);
      setTimeout(()=>{ if(alive()&&m.readyState===0) streamFailed(); },3500);
    }
  }else{
    m.src=url; tryPlay(m);
  }
  m.addEventListener('playing',()=>{ if(alive()){ playerState(t('state_playing'),'var(--cyan)'); box.querySelectorAll('.play-overlay').forEach(e=>e.remove()); } });
  m.addEventListener('error',()=>streamFailed());
}
function setActiveSrc(i){
  if(!state.current) return;
  const urls=state.current._urls;
  state.selSrc=i;
  $('#mSrcNo').textContent=t('src_no_fmt',i+1,urls.length);
  $('#mSrcUrl').textContent=urls[i]||'';
  $('#mSrcUrl').title=urls[i]||'';
  playerState(t('state_connecting'));
}

/* ============================ 点阵地球 ============================ */
const gc=$('#globe'),gx=gc.getContext('2d');
const sc=$('#stars'),sx=sc.getContext('2d');
let W=0,H=0,DPR=1,stars=[],landPts=[],gCX=0,gCY=0,gR=0;
function globeLayout(){
  const mob=W<=700, short=H<=500&&W>H;
  gCX = mob ? W*.5 : W*.60;
  gCY = mob ? (short?H*.52:H*.66) : H*.49;
  gR  = mob ? Math.min(W*.42,H*(short?.30:.25),230) : Math.min(H*.33,300);
  const halo=document.querySelector('.globe-halo');
  if(halo){
    halo.style.width=halo.style.height=(gR*2.1)+'px';
    halo.style.left=gCX+'px'; halo.style.top=gCY+'px';
    halo.style.transform='translate(-50%,-50%)';
  }
  const c=$('#globeCount');
  if(c){ c.style.left=gCX+'px'; c.style.top=Math.max(64,gCY-gR-30)+'px'; }
}
const CONTINENTS=[
  [[-168,66],[-140,70],[-125,49],[-117,32],[-97,16],[-82,25],[-66,45],[-60,55],[-95,72]],
  [[-81,12],[-60,10],[-35,-7],[-38,-23],[-55,-55],[-72,-52],[-80,-20]],
  [[-10,36],[0,44],[10,37],[20,40],[30,45],[40,60],[30,70],[10,71],[-5,58]],
  [[-17,15],[10,37],[33,31],[43,12],[51,11],[40,-15],[35,-34],[18,-35],[8,-5]],
  [[30,70],[60,75],[100,78],[140,70],[170,60],[140,35],[120,20],[105,10],[80,8],[60,25],[45,30],[30,45]],
  [[113,-11],[130,-12],[153,-28],[146,-39],[115,-35]],
  [[-52,60],[-20,70],[-25,83],[-60,82]],
  [[26,60],[30,70],[45,68],[60,60],[45,55],[30,58]]
];
function inPoly(lon,lat,poly){
  let inside=false;
  for(let i=0,j=poly.length-1;i<poly.length;j=i++){
    const xi=poly[i][0],yi=poly[i][1],xj=poly[j][0],yj=poly[j][1];
    if(((yi>lat)!==(yj>lat))&&(lon<(xj-xi)*(lat-yi)/(yj-yi)+xi)) inside=!inside;
  }
  return inside;
}
function buildSphere(){
  landPts=[]; const N=3800,ga=Math.PI*(3-Math.sqrt(5));
  for(let i=0;i<N;i++){
    const y=1-(i/(N-1))*2,r=Math.sqrt(1-y*y),th=ga*i;
    const x=Math.cos(th)*r,z=Math.sin(th)*r;
    const lat=Math.asin(y)*180/Math.PI,lon=Math.atan2(x,z)*180/Math.PI;
    landPts.push({x:x,y:y,z:z,land:CONTINENTS.some(p=>inPoly(lon,lat,p))});
  }
}
function resize(){
  DPR=Math.min(window.devicePixelRatio||1,2);
  // clientWidth/Height 不受移动端「自动缩放布局视口」影响，避免画布反过来把页面撑宽
  W=document.documentElement.clientWidth||window.innerWidth;
  H=document.documentElement.clientHeight||window.innerHeight;
  [gc,sc].forEach(c=>{c.width=W*DPR;c.height=H*DPR;c.style.width=W+'px';c.style.height=H+'px';});
  gx.setTransform(DPR,0,0,DPR,0,0); sx.setTransform(DPR,0,0,DPR,0,0);
  globeLayout();
  if(typeof updateGlobeHint==='function') updateGlobeHint();
  if(typeof renderStatus==='function') renderStatus();
  const n=W<=700?130:230;
  stars=Array.from({length:n},()=>({x:Math.random()*W,y:Math.random()*H,r:Math.random()*1.3+.2,a:Math.random(),s:Math.random()*.02+.004}));
}
function project(lat,lon){
  const la=lat*Math.PI/180,lo=lon*Math.PI/180;
  let x=Math.cos(la)*Math.sin(lo),y=Math.sin(la),z=Math.cos(la)*Math.cos(lo);
  const cy=Math.cos(state.rotY),sy=Math.sin(state.rotY);
  const x1=x*cy-z*sy,z1=x*sy+z*cy;
  const cx=Math.cos(state.rotX),sxr=Math.sin(state.rotX);
  return {x:x1,y:y*cx-z1*sxr,z:y*sxr+z1*cx};
}
function rebuildPoints(){
  const m=new Map();
  for(const ch of data()){
    if(ch.lat==null||ch.lon==null) continue;
    const k=ch.cc||ch.c;
    let o=m.get(k);
    if(!o){ o={cc:k,c:ch.c,lat:ch.lat,lon:ch.lon,count:0}; m.set(k,o); }
    o.count++;
  }
  state.points=[...m.values()]; state.pointsDirty=false;
}
function drawStars(t){
  sx.clearRect(0,0,W,H);
  for(const s of stars){
    const a=.18+.55*Math.abs(Math.sin(t*s.s+s.a*10));
    sx.beginPath(); sx.arc(s.x,s.y,s.r,0,Math.PI*2);
    sx.fillStyle='rgba(200,225,255,'+a.toFixed(2)+')'; sx.fill();
  }
}
function drawGlobe(t){
  gx.clearRect(0,0,W,H);
  const cx=gCX,cy=gCY,R=gR*state.zoom;
  const g=gx.createRadialGradient(cx,cy,R*.55,cx,cy,R*1.35);
  g.addColorStop(0,'rgba(60,140,220,.10)'); g.addColorStop(1,'rgba(60,140,220,0)');
  gx.fillStyle=g; gx.beginPath(); gx.arc(cx,cy,R*1.35,0,Math.PI*2); gx.fill();
  const dg=gx.createRadialGradient(cx-R*.3,cy-R*.35,R*.05,cx,cy,R);
  dg.addColorStop(0,'rgba(18,40,78,.55)'); dg.addColorStop(.65,'rgba(9,20,44,.72)'); dg.addColorStop(1,'rgba(4,9,22,.92)');
  gx.fillStyle=dg; gx.beginPath(); gx.arc(cx,cy,R,0,Math.PI*2); gx.fill();
  gx.lineWidth=.6; gx.strokeStyle='rgba(120,170,240,.10)';
  for(let lat=-60;lat<=60;lat+=30){
    gx.beginPath(); let st=false;
    for(let lon=-180;lon<=180;lon+=6){
      const p=project(lat,lon);
      if(p.z>0){const X=cx+p.x*R,Y=cy-p.y*R; if(!st){gx.moveTo(X,Y);st=true;}else gx.lineTo(X,Y);}else st=false;
    }
    gx.stroke();
  }
  for(let lon=-180;lon<180;lon+=30){
    gx.beginPath(); let st=false;
    for(let lat=-88;lat<=88;lat+=6){
      const p=project(lat,lon);
      if(p.z>0){const X=cx+p.x*R,Y=cy-p.y*R; if(!st){gx.moveTo(X,Y);st=true;}else gx.lineTo(X,Y);}else st=false;
    }
    gx.stroke();
  }
  const cosY=Math.cos(state.rotY),sinY=Math.sin(state.rotY),cosX=Math.cos(state.rotX),sinX=Math.sin(state.rotX);
  for(const p of landPts){
    const x=p.x*cosY-p.z*sinY, z0=p.x*sinY+p.z*cosY;
    const y=p.y*cosX-z0*sinX, z=p.y*sinX+z0*cosX;
    if(z<=.02) continue;
    const X=cx+x*R,Y=cy-y*R,depth=.28+.72*z;
    if(p.land){ const sz=1.5+depth*1.2; gx.fillStyle='rgba(115,246,224,'+(depth*.88).toFixed(2)+')'; gx.fillRect(X,Y,sz,sz); }
    else { gx.fillStyle='rgba(80,135,210,'+(depth*.055).toFixed(2)+')'; gx.fillRect(X,Y,1,1); }
  }
  gx.lineWidth=7; gx.strokeStyle='rgba(90,180,255,.055)'; gx.beginPath(); gx.arc(cx,cy,R+3,0,Math.PI*2); gx.stroke();
  gx.lineWidth=1.5; gx.strokeStyle='rgba(135,205,255,.34)'; gx.beginPath(); gx.arc(cx,cy,R,0,Math.PI*2); gx.stroke();
  if(state.pointsDirty) rebuildPoints();
  state.hotspots=[];
  for(const o of state.points){
    const p=project(o.lat,o.lon); if(p.z<=.06) continue;
    const X=cx+p.x*R,Y=cy-p.y*R;
    const sel=state.selectedCountry&&state.selectedCountry===o.c;
    const r=sel?7:Math.min(3.2+Math.log2(o.count+1)*.7,7);
    const pulse=1.6+Math.sin(t*.0026+X*.02)*.9;
    gx.beginPath(); gx.arc(X,Y,r+pulse+3,0,Math.PI*2);
    gx.fillStyle=sel?'rgba(255,207,122,.18)':'rgba(94,234,212,.10)'; gx.fill();
    gx.beginPath(); gx.arc(X,Y,r,0,Math.PI*2);
    gx.fillStyle=sel?'#ffcf7a':'#7ff0dd'; gx.fill();
    state.hotspots.push({x:X,y:Y,r:Math.max(14,r+10),o:o});
  }
}
function loop(t){ drawStars(t); if(!state.drag) state.rotY+=.00042; drawGlobe(t); requestAnimationFrame(loop); }

/* ============================ 模式 ============================ */
function setMode(m){
  state.mode=m; state.page=1; state.country='';state.cat='';state.lang='';state.q='';state.selectedCountry=null;
  state.imported=null; state.pointsDirty=true;
  $$('#tabTV,#tabRadio').forEach(a=>{
    const on=a.dataset.mode===m;
    a.classList.toggle('on',on);
    if(on) a.setAttribute('aria-current','page'); else a.removeAttribute('aria-current');
  });
  applyI18n();
  applySEO();
  updateGlobeHint();
  updateGlobeCount();
  fillFilters(); renderList(); renderStatus();
  if(['idle','cache','pending'].includes(state.src[m].status)) loadData(m);
}

/* ============================ 反馈（同源 /api/feedback） ============================ */
const FB_API='/api/feedback', FB_OUTBOX='pip_fb_outbox';
let fbOnline=false, fbChecked=false, fbSending=false, fbOpenedAt=0, fbItems=[], fbLocalView=false, fbProvider='';

function fbOutbox(){ try{ return JSON.parse(localStorage.getItem(FB_OUTBOX)||'[]'); }catch(e){ return []; } }
function fbOutboxPush(o){
  const a=fbOutbox(); a.push(Object.assign({at:new Date().toISOString(),via:'local'},o));
  try{ localStorage.setItem(FB_OUTBOX,JSON.stringify(a.slice(-100))); }catch(e){}
  fbUpdateStatus();
}
function fbCtxText(){
  return t('fb_ctx',t(isTV()?'name_tv':'name_radio'),curLang().label,state.current?state.current.n:'—');
}
function fbUpdateOffline(){
  const box=$('#fbOffline'); if(!box) return;
  box.classList.toggle('hide',fbOnline);
  if(!fbOnline) box.innerHTML=t('fb_offline');
  const ctx=$('#fbCtx'); if(ctx) ctx.innerHTML=fbCtxText();
  fbUpdateStatus();
}
function fbUpdateStatus(){
  const e=$('#stFB'); if(!e) return;
  e.textContent=fbOnline?t('fb_state_on',fbProvider||'KV'):t('fb_state_off');
}
async function fbProbe(){
  if(fbChecked) return;
  if(!/^https?:$/i.test(location.protocol)){ fbOnline=false; fbChecked=true; fbUpdateOffline(); return; }
  try{
    const r=await fetch(FB_API,{method:'GET',headers:{'Accept':'application/json'},cache:'no-store'});
    const j=await r.json().catch(()=>({}));
    fbOnline=!!(r.ok&&j&&j.service==='feedback');
    if(fbOnline) fbProvider=j.provider||'KV';
  }catch(e){ fbOnline=false; }
  fbChecked=true; fbUpdateOffline();
}
function fbSetMsg(txt,cls){
  const e=$('#fbMsgBox'); if(!e) return;
  e.textContent=txt; e.className='fb-msg'+(cls?' '+cls:'');
}
function fbCount(){ const e=$('#fbCount'); if(e) e.textContent=$('#fbMsg').value.length+' / 1000'; }
function openFeedback(){
  fbOpenedAt=Date.now();
  $('#feedback').classList.remove('hide');
  fbSetMsg('',''); fbCount(); fbUpdateOffline();
  if(!fbChecked) fbProbe();
  setTimeout(()=>{ if((document.documentElement.clientWidth||window.innerWidth)>700) $('#fbMsg').focus(); },240);
}
function closeFeedback(){ $('#feedback').classList.add('hide'); }
function fbRefreshUI(){
  if(!$('#feedback')) return;
  fbUpdateOffline(); fbCount();
  if(!fbSending) $('#fbSubmit').textContent=t('fb_submit');
  if(fbItems.length) fbRender(fbItems,fbLocalView);
}
function fbClearForm(){ $('#fbMsg').value=''; $('#fbEmail').value=''; $('#fbHp').value=''; fbCount(); }
async function fbSubmit(e){
  e.preventDefault();
  if(fbSending) return;
  const msg=$('#fbMsg').value.trim(), email=$('#fbEmail').value.trim(), kind=$('#fbType').value;
  if(msg.length<5){ fbSetMsg(t('fb_short'),'err'); return; }
  if(Date.now()-fbOpenedAt<1200){ fbSetMsg(t('fb_wait'),'warn'); return; }
  if($('#fbHp').value) return;                       // 蜜罐：静默丢弃
  const payload={
    type:kind,message:msg,email:email,botcheck:$('#fbHp').value,
    channel:state.current?state.current.n:'',mode:state.mode,lang:state.uiLang,
    url:location.href.split('#')[0]
  };
  fbSending=true;
  const btn=$('#fbSubmit'); btn.disabled=true; btn.textContent=t('fb_sending');
  if(fbOnline){
    try{
      const r=await fetch(FB_API,{
        method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},
        body:JSON.stringify(payload)
      });
      const j=await r.json().catch(()=>({}));
      if(!r.ok||j.ok===false) throw new Error(j.error||('HTTP '+r.status));
      fbSetMsg(t('fb_ok'),'ok'); toast(t('toast_fb_sent')); fbClearForm();
    }catch(err){
      fbOutboxPush(payload);                          // 失败也不丢内容
      fbSetMsg(t('fb_fail'),'err');
    }
  }else{
    fbOutboxPush(payload);
    fbSetMsg(t('fb_ok_local'),'warn'); toast(t('toast_fb_local')); fbClearForm();
  }
  fbSending=false; btn.disabled=false; btn.textContent=t('fb_submit');
}
function fbKind(k){ return t('fb_kind_'+(/^(bug|dead|idea)$/.test(k)?k:'other')); }
function fbRender(items,local){
  const box=$('#fbList'); if(!box) return;
  fbItems=items||[]; fbLocalView=!!local;
  if(!fbItems.length){ box.innerHTML='<div class="fb-empty">'+esc(t('fb_admin_empty'))+'</div>'; return; }
  box.innerHTML=fbItems.slice(0,50).map(x=>{
    const at=x.at?new Date(x.at).toLocaleString(curLang().intl,{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}):'';
    const meta=[at,fbKind(x.type),x.channel||'',x.email||''].filter(Boolean).map(esc).join(' · ');
    return '<div class="fb-item"><div class="top"><span class="kind">'+esc(fbKind(x.type))+'</span><span>'+meta+'</span></div>'+
      '<div class="txt">'+esc(String(x.message||''))+'</div></div>';
  }).join('');
}
async function fbLoad(){
  const m=$('#fbAdminMsg'); m.className='fb-msg'; m.textContent='';
  if(!fbOnline){
    const a=fbOutbox(); fbRender(a,true);
    m.className='fb-msg warn'; m.textContent=a.length?t('fb_admin_local',a.length)+' · '+t('fb_admin_na'):t('fb_admin_na');
    return;
  }
  const token=$('#fbToken').value.trim();
  if(!token){ m.className='fb-msg err'; m.textContent=t('fb_admin_denied'); return; }
  $('#fbLoad').disabled=true;
  try{
    const r=await fetch(FB_API,{method:'GET',headers:{'X-Admin-Token':token,'Accept':'application/json'},cache:'no-store'});
    const j=await r.json().catch(()=>({}));
    if(r.status===401||r.status===403){ m.className='fb-msg err'; m.textContent=t('fb_admin_denied'); return; }
    if(!r.ok||j.ok===false) throw new Error(j.error||('HTTP '+r.status));
    fbRender(j.items||[],false);
    m.className='fb-msg ok'; m.textContent=t('fb_admin_count',j.total!=null?j.total:(j.items||[]).length,(j.items||[]).length);
  }catch(err){ m.className='fb-msg err'; m.textContent=t('fb_admin_err',err.message||'network'); }
  finally{ $('#fbLoad').disabled=false; }
}
function fbExport(){
  const items=fbItems.length?fbItems:fbOutbox();
  const blob=new Blob([JSON.stringify(items,null,2)],{type:'application/json;charset=utf-8'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob);
  a.download='feedback-'+new Date().toISOString().slice(0,10)+'.json';
  document.body.appendChild(a); a.click();
  setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},300);
  toast(t('toast_fb_export',items.length));
}
$('#btnFeedback').addEventListener('click',openFeedback);
$('#fbClose').addEventListener('click',closeFeedback);
$('#feedback').addEventListener('click',e=>{ if(e.target===$('#feedback')) closeFeedback(); });
$('#fbForm').addEventListener('submit',fbSubmit);
$('#fbMsg').addEventListener('input',fbCount);
$('#fbReset').addEventListener('click',()=>{ fbClearForm(); fbSetMsg('',''); });
$('#fbLoad').addEventListener('click',fbLoad);
$('#fbExport').addEventListener('click',fbExport);

/* ============================ 事件 ============================ */
$$('nav a[data-mode]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();setMode(a.dataset.mode);}));
$('#navList').addEventListener('click',e=>{e.preventDefault();openPanel();});
$('#btnFind').addEventListener('click',openPanel);
$('#dkList').addEventListener('click',openPanel);
$('#dkFilter').addEventListener('click',()=>{openPanel();setTimeout(()=>{if((document.documentElement.clientWidth||window.innerWidth)>700)$('#fCountry').focus();},280);});
$('#dkFav').addEventListener('click',()=>{state.favOnly=!state.favOnly;$('#btnOnlyFav').textContent=t(state.favOnly?'btn_fav_on':'btn_fav_off');openPanel();toast(t(state.favOnly?'toast_fav_on':'toast_fav_off'));});
$('#dkRefresh').addEventListener('click',()=>loadData(state.mode,true));
$('#dkNext').addEventListener('click',nextChannel);
$('#panelClose').addEventListener('click',closePanel);
let suppressScrimClick=0; // 点地图打开抽屉时，浏览器补发的那一次 click 不能落到遮罩上把抽屉又关掉
$('#scrim').addEventListener('click',()=>{ if(Date.now()<suppressScrimClick) return; closePanel(); });
$('#srcChip').addEventListener('click',()=>{ if(state.src[state.mode].status==='error') loadData(state.mode,true); else openSettings(); });

$('#q').addEventListener('input',e=>{state.q=e.target.value;state.page=1;renderList();});
$('#fCountry').addEventListener('change',e=>{state.country=e.target.value;state.page=1;state.selectedCountry=e.target.value||null;renderList();});
$('#fCat').addEventListener('change',e=>{state.cat=e.target.value;state.page=1;renderList();});
$('#fLang').addEventListener('change',e=>{state.lang=e.target.value;state.page=1;renderList();});
$('#list').addEventListener('click',e=>{
  if(e.target.id==='btnMore'){ state.page++; renderList(); return; }
  const fav=e.target.closest('[data-fav]');
  if(fav){
    const n=fav.getAttribute('data-fav');
    if(state.fav.has(n)) state.fav.delete(n); else state.fav.add(n);
    try{localStorage.setItem('pip_fav',JSON.stringify([...state.fav]));}catch(err){}
    syncFavBtn(); renderList(); return;
  }
  const card=e.target.closest('.card');
  if(card){ const ch=data()[+card.dataset.i]; if(ch) openChannel(ch); }
});
$('#btnReset').addEventListener('click',()=>{
  state.q='';state.country='';state.cat='';state.lang='';state.favOnly=false;state.page=1;state.selectedCountry=null;
  $('#q').value='';$('#btnOnlyFav').textContent=t('btn_fav_off');fillFilters();renderList();toast(t('toast_reset'));
});
$('#btnOnlyFav').addEventListener('click',()=>{state.favOnly=!state.favOnly;state.page=1;$('#btnOnlyFav').textContent=t(state.favOnly?'btn_fav_on':'btn_fav_off');renderList();});
$('#btnExport').addEventListener('click',()=>download('公共电视-'+(isTV()?'电视':'电台')+'.m3u',m3uFor(filtered())));
$('#btnExportTop').addEventListener('click',()=>download('公共电视-'+(isTV()?'电视':'电台')+'.m3u',m3uFor(filtered())));
$('#btnImport').addEventListener('click',()=>$('#fileInput').click());
$('#fileInput').addEventListener('change',e=>{
  const f=e.target.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{
    const items=parseLocalM3U(String(r.result),f.name);
    if(!items.length){ toast(t('toast_import_empty')); return; }
    state.imported=items; state.data[state.mode]=items;
    state.src[state.mode]={status:'demo',count:items.length,total:items.length,via:'本地导入',msg:'',at:Date.now()};
    state.pointsDirty=true; state.q='';state.country='';state.cat='';state.lang='';state.page=1;
    fillFilters();renderList();renderStatus();openPanel();
    toast(t('toast_import_ok',fmtNum(items.length),f.name));
  };
  r.readAsText(f); e.target.value='';
});

$('#mClose').addEventListener('click',closeModal);
$('#btnFav').addEventListener('click',()=>{ if(state.current) toggleFav(state.current.n); });
$('#modal').addEventListener('click',e=>{if(e.target===$('#modal'))closeModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){
  if(!$('#settings').classList.contains('hide')) closeSettings();
  else if(!$('#feedback').classList.contains('hide')) closeFeedback();
  else if(!$('#modal').classList.contains('hide')) closeModal();
  else closePanel();
}});
$('#btnNextSrc').addEventListener('click',()=>{
  if(!state.current||!state.current._urls.length) return;
  const n=state.current._urls.length;
  retryLeft=Math.min(4,n-1);
  setActiveSrc((state.selSrc+1)%n);
  loadStream(state.current._urls[state.selSrc]);
});

function surprise(){ const l=filtered(); if(!l.length){toast(t('toast_no_result'));return;} openChannel(l[Math.floor(Math.random()*Math.min(l.length,400))]); }
function nextChannel(){ const l=filtered(); if(!l.length){toast(t('toast_no_channel'));return;} const i=state.current?l.indexOf(state.current):-1; const lim=Math.min(l.length,400); openChannel(l[i<0?0:(i+1)%lim]); }
$('#btnSurprise').addEventListener('click',surprise);

/* 设置面板 */
function openSettings(){ loadCfg(); renderStatus(); $('#settings').classList.remove('hide'); }
function closeSettings(){ $('#settings').classList.add('hide'); }
$('#btnSettings').addEventListener('click',openSettings);
$('#setClose').addEventListener('click',closeSettings);
$('#settings').addEventListener('click',e=>{if(e.target===$('#settings'))closeSettings();});
$('#setSave').addEventListener('click',()=>{ saveCfg(); closeSettings(); loadData('tv',true); loadData('radio',true); toast(t('toast_saved')); });
$('#setDefault').addEventListener('click',()=>{
  $('#cfgIptv').value=CONF.iptv; $('#cfgRadio').value=CONF.radio;
  $('#cfgLimit').value=String(CONF.limit); $('#cfgRadioMode').value=CONF.radioMode;
  $('#cfgLang').value=state.uiLang;
  saveCfg(); toast(t('toast_default'));
});
$('#setClear').addEventListener('click',()=>{ try{localStorage.removeItem('pip_cache_tv');localStorage.removeItem('pip_cache_radio');}catch(e){} toast(t('toast_clear')); });

/* 语言菜单 / 设置里的语言下拉 */
$('#btnLang').addEventListener('click',e=>{
  e.stopPropagation();
  if($('#langMenu').classList.contains('show')) closeLangMenu(); else openLangMenu();
});
$('#langMenu').addEventListener('click',e=>{
  const b=e.target.closest('[data-lang]'); if(b){ setLang(b.dataset.lang); }
});
$('#cfgLang').addEventListener('change',e=>setLang(e.target.value));
document.addEventListener('click',e=>{
  if(!e.target.closest('.lang-wrap')) closeLangMenu();
});
document.addEventListener('keydown',e=>{ if(e.key==='Escape') closeLangMenu(); });

/* 地球交互：单指旋转 / 双指缩放 / 滚轮缩放 / 点按选国家 */
const ptrs=new Map(); let pinch=null;
const clampZoom=z=>Math.max(.65,Math.min(1.85,z));
function ptrDist(){ const a=[...ptrs.values()]; return a.length<2?0:Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y); }
gc.addEventListener('pointerdown',e=>{
  ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  try{ gc.setPointerCapture(e.pointerId); }catch(err){}
  if(ptrs.size===1){
    state.drag={x:e.clientX,y:e.clientY,ry:state.rotY,rx:state.rotX,moved:false};
  }else if(ptrs.size===2){
    state.drag=null; pinch={d:ptrDist()||1,z:state.zoom};
  }
});
gc.addEventListener('pointermove',e=>{
  if(!ptrs.has(e.pointerId))return;
  ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(ptrs.size>=2&&pinch){
    const d=ptrDist(); if(d>0) state.zoom=clampZoom(pinch.z*(d/pinch.d));
    return;
  }
  if(!state.drag)return;
  const dx=e.clientX-state.drag.x,dy=e.clientY-state.drag.y;
  if(Math.abs(dx)+Math.abs(dy)>5)state.drag.moved=true;
  state.rotY=state.drag.ry+dx*(W<=700?.007:.006);
  state.rotX=Math.max(-1.1,Math.min(1.1,state.drag.rx+dy*.005));
});
function endPointer(e,allowTap){
  ptrs.delete(e.pointerId);
  if(ptrs.size<2)pinch=null;
  if(ptrs.size!==0){ state.drag=null; return; }
  const moved=state.drag?state.drag.moved:true;
  state.drag=null;
  if(!allowTap||moved)return;
  const r=gc.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
  let best=null,bd=1e9;
  for(const h of state.hotspots){const d=Math.hypot(h.x-x,h.y-y);if(d<bd&&d<h.r){bd=d;best=h;}}
  const mob=(document.documentElement.clientWidth||window.innerWidth)<=700;
  // 手机上点地球任意位置（不要求精确命中光点）也打开列表：
  // 命中光点按该国家筛选，没命中就显示全部，避免小屏上光点太难点
  const inGlobe=Math.hypot(x-gCX,y-gCY)<=gR*1.3;
  if(best){
    state.country=best.o.c;state.selectedCountry=best.o.c;state.q='';state.page=1;
    $('#q').value='';fillFilters();renderList();
    suppressScrimClick=Date.now()+450; openPanel();
    toast(t('toast_country',flag(best.o.cc),dispCountry(best.o.c,best.o.cc),fmtNum(best.o.count)));
  }else if(mob&&inGlobe){
    state.country='';state.selectedCountry=null;state.q='';state.page=1;
    $('#q').value='';fillFilters();renderList();
    suppressScrimClick=Date.now()+450; openPanel();
    toast(t('toast_map_all'));
  }
}
gc.addEventListener('pointerup',e=>endPointer(e,true));
gc.addEventListener('pointercancel',e=>endPointer(e,false));
gc.addEventListener('wheel',e=>{e.preventDefault();state.zoom=clampZoom(state.zoom*(e.deltaY>0?.92:1.08));},{passive:false});
window.addEventListener('resize',resize);
window.addEventListener('orientationchange',()=>setTimeout(resize,180));

/* ============================ SEO（随界面语言更新） ============================ */
let seoReady=false;
function applySEO(){
  const L=curLang(), tv=isTV();
  document.documentElement.lang=L.html;
  document.title=t(modeKey('seo_title'));
  const md=$('meta[name="description"]'); if(md) md.content=t(modeKey('seo_desc'));
  const setMeta=(sel,v)=>{ const m=$(sel); if(m) m.content=v; };
  setMeta('meta[property="og:title"]',t(modeKey('seo_title')));
  setMeta('meta[property="og:description"]',t(modeKey('seo_desc')));
  setMeta('meta[property="og:locale"]',L.html.replace('-','_'));
  setMeta('meta[name="twitter:title"]',t('seo_title'));
  setMeta('meta[name="twitter:description"]',t('seo_desc'));
  // 静态 JSON-LD 里的名称与语言同步
  $$('script[type="application/ld+json"]').forEach(s=>{
    try{
      const o=JSON.parse(s.textContent);
      if(o.name!==undefined) o.name=t('brand');
      if(o.inLanguage!==undefined) o.inLanguage=L.html;
      if(o.description!==undefined) o.description=t('seo_desc');
      s.textContent=JSON.stringify(o);
    }catch(e){}
  });
  if(seoReady) return;
  seoReady=true;
  const http=/^https?:$/i.test(location.protocol);
  if(http){
    const base=location.href.split('#')[0].split('?')[0];
    $('#seoCanonical').href=base;
    $$('meta[property="og:image"],meta[name="twitter:image"]').forEach(m=>{
      m.content=new URL('public-iptv-og.png',base).href;
    });
    const ld=document.createElement('script'); ld.type='application/ld+json';
    ld.textContent=JSON.stringify({
      '@context':'https://schema.org','@type':'WebSite','name':t('brand'),'inLanguage':L.html,'url':base,
      'potentialAction':{'@type':'SearchAction','target':base+'?q={search_term_string}','query-input':'required name=search_term_string'}
    });
    document.head.appendChild(ld);
  }else{
    const c=$('#seoCanonical'); if(c) c.remove();
  }
  // ?q=关键词 可直接深链到搜索结果
  const q=new URLSearchParams(location.search).get('q');
  if(q){ state.q=q; $('#q').value=q; state.page=1; renderList(); openPanel(); }
}

/* ============================ 启动 ============================ */
loadCfg();
for(const m of ['tv','radio']){
  const c=loadCache(m);
  if(c){ state.data[m]=c.items; state.src[m]={status:'cache',count:c.items.length,total:c.total||c.items.length,via:c.via||'',msg:'',at:c.at}; }
}
if(!state.data.tv.length){ state.data.tv=DEMO_TV; if(state.src.tv.status==='idle') state.src.tv={status:'pending',count:DEMO_TV.length,total:DEMO_TV.length,via:'',msg:'',at:0}; }
if(!state.data.radio.length){ state.data.radio=DEMO_RADIO; if(state.src.radio.status==='idle') state.src.radio={status:'pending',count:DEMO_RADIO.length,total:DEMO_RADIO.length,via:'',msg:'',at:0}; }
buildSphere();resize();buildLangOptions();applyI18n();applySEO();
fillFilters();renderList();renderStatus();updateGlobeCount();requestAnimationFrame(loop);
fbProbe();
loadData('tv');
})();
