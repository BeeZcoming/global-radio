// Cloudflare Pages Function -> /api/feedback
// Git 集成时由 Cloudflare 自动编译（控制台拖拽上传不会编译 functions/，必须用 Git 或 Wrangler）。
// 绑定：Settings → Functions → KV namespace bindings，变量名 FEEDBACK
//       Settings → Environment variables → secret ADMIN_TOKEN

const API_PATH = '/api/feedback';
const JSON_HEAD = {
  'Content-Type': 'application/json; charset=utf-8',
  'Cache-Control': 'no-store, private',
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer'
};
const PREFIX = 'fb:';
const MAX_READ = 200;
const KV_TTL = 15552000;      // 180 天
const RATE_WINDOW = 60;
const RATE_MAX = 5;

function json(data, status) {
  return new Response(JSON.stringify(data), { status: status || 200, headers: JSON_HEAD });
}
function str(v, max) { return String(v == null ? '' : v).slice(0, max); }
function hasStore(env) { return !!(env && env.FEEDBACK && typeof env.FEEDBACK.put === 'function'); }
function hasHook(env) { return !!(env && env.FEEDBACK_WEBHOOK); }
function eq(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}
function uuid() {
  try { return crypto.randomUUID(); } catch (e) {}
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export async function feedback(request, env, ctx) {
  const store = hasStore(env), hook = hasHook(env);
  if (!store && !hook) {
    // 未配置：前端 fbProbe 判定离线，自动降级到本机暂存，不报错
    return json({ ok: false, service: 'unconfigured', error: 'feedback_not_configured' }, 503);
  }
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: JSON_HEAD });

  if (request.method === 'GET') {
    const token = request.headers.get('X-Admin-Token');
    if (token) {
      if (!store) return json({ ok: true, items: [], total: 0, note: 'webhook-only mode: no history stored' });
      if (!env.ADMIN_TOKEN) return json({ ok: false, error: 'admin_token_not_set' }, 403);
      if (!eq(token, env.ADMIN_TOKEN)) return json({ ok: false, error: 'forbidden' }, 403);
      const list = await env.FEEDBACK.list({ prefix: PREFIX, limit: 1000 });
      const keys = list.keys.map(k => k.name).sort().reverse().slice(0, MAX_READ);
      const rows = await Promise.all(keys.map(k => env.FEEDBACK.get(k, 'json').catch(() => null)));
      return json({ ok: true, items: rows.filter(Boolean), total: list.keys.length });
    }
    return json({ ok: true, service: 'feedback', provider: store ? 'KV' : 'Webhook' });
  }
  if (request.method !== 'POST') return json({ ok: false, error: 'method_not_allowed' }, 405);

  let body;
  try { body = await request.json(); } catch (e) { return json({ ok: false, error: 'invalid_json' }, 400); }
  if (!body || typeof body !== 'object') return json({ ok: false, error: 'invalid_json' }, 400);
  if (str(body.botcheck, 100)) return json({ ok: true, ignored: true });
  const message = str(body.message, 1000).trim();
  if (message.length < 5) return json({ ok: false, error: 'message_too_short' }, 400);

  const item = {
    at: new Date().toISOString(),
    type: /^(bug|dead|idea|other)$/.test(body.type) ? body.type : 'other',
    message: message,
    email: str(body.email, 200).trim(),
    channel: str(body.channel, 200),
    mode: str(body.mode, 20),
    lang: str(body.lang, 10),
    url: str(body.url, 500),
    country: str(request.headers.get('CF-IPCountry'), 8)
  };
  if (store) {
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    const rk = 'rl:' + ip;
    let n = 0;
    try { n = parseInt((await env.FEEDBACK.get(rk)) || '0', 10) || 0; } catch (e) {}
    if (n >= RATE_MAX) return json({ ok: false, error: 'rate_limited' }, 429);
    ctx.waitUntil(env.FEEDBACK.put(rk, String(n + 1), { expirationTtl: RATE_WINDOW }));
    await env.FEEDBACK.put(PREFIX + item.at + ':' + uuid(), JSON.stringify(item), { expirationTtl: KV_TTL });
  }
  if (hook) {
    const text = '[公共电视反馈] ' + item.type + ' / ' + (item.channel || '—') + '\n' +
      item.message + (item.email ? '\n联系：' + item.email : '') + '\n' + item.at + ' · ' + item.url;
    ctx.waitUntil(fetch(env.FEEDBACK_WEBHOOK, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text })
    }).catch(() => {}));
  }
  return json({ ok: true, at: item.at }, 201);
}

export async function onRequestGet(context) {
  return feedback(context.request, context.env, context);
}
export async function onRequestPost(context) {
  return feedback(context.request, context.env, context);
}
export async function onRequestOptions(context) {
  return new Response(null, { status: 204, headers: JSON_HEAD });
}
