# GitHub 连动部署：拆分版（不用在本地敲任何命令）

## 先说清楚：为什么之前「还是一样」

你反复看到的 **「不能将绑定添加到只有静态资产的 Worker」**，跟 `index.html` 是不是单文件、跟文件多大、跟 KV 本身都**没有关系**。

新版 Cloudflare 控制台把 Workers 和 Pages 合并了，创建出来的项目默认都是「Worker + 静态资产」。**只要项目里没有可执行的 Worker 入口代码（`main`），控制台就把它归类为 assets-only Worker，直接禁用绑定/变量面板** —— 绑定是给 Worker 代码用的，没代码就没处挂。反过来，一旦配置里出现真正的 `main`，这个面板立刻解锁。

所以之前拖拽 `_worker.js` 反复失败，是因为那个文件**只被当成普通静态文件上传了，没有成为 Worker 入口**。换包、改 webhook 地址、重建项目都绕不开这一点。

**这次的解法**：把 `index.html` 拆成 CSS/JS（你提的方向，也让静态资源目录和 Worker 代码彻底分离），然后用 **GitHub 连动**让 Cloudflare 读取仓库里的 `wrangler.jsonc` —— 里面写了明确的 `main`。项目变成真 Worker，绑定面板解锁，`npx wrangler deploy` 也不再报 `Missing entry-point`（上次那个错就是缺 `main`）。

> 顺带说：拆 CSS/JS 本身不解决绑定问题，但它让「Worker 代码在 `worker/`、静态资源在 `public/`」的边界清晰，避免 Worker 文件被误当成静态资产上传 —— 这是官方迁移文档特别提醒的坑。

---

## 全程不用本地命令

- 文件通过 **GitHub 网页上传**（新建仓库 → uploading an existing file → 拖文件夹），不用装 Git、不用 `git push`
- 需要执行的命令（如 `npx wrangler deploy`）是**填在 Cloudflare 控制台表单里的字段**，由 Cloudflare 自己跑，不是你在终端敲
- 不用 Node.js、不用 Wrangler 本地安装、不用 API Token

---

## 第 0 步：选 A 还是 B（只选一次）

| 判断依据 | 用哪套 |
| --- | --- |
| 上次日志里有 `Executing user deploy command: npx wrangler deploy`；控制台创建项目时要填 **Deploy command**；项目网址是 `xxx.workers.dev` | **A 包（主推）**：`cloudflare-workers-github.zip` |
| 控制台里能明确看到 **Create → Pages 标签 → Connect to Git**，构建设置里有 **Build output directory** 且没有 Deploy command | **B 包**：`cloudflare-pages-github.zip` |

**你上次的日志属于 A。** 下面先写 A 的完整步骤，B 在后面一节。

两套**不要混**：`wrangler.jsonc` + `worker/` 是 A，`wrangler.toml` + `functions/` 是 B，同时放进一个仓库会冲突。

---

# A 包：Workers Builds（推荐）

## 第 A1 步：解压，看目录

```
cloudflare-workers-github/
├── public/                    静态资源（assets.directory 指向这里）
│   ├── index.html             ← 已拆分，只剩结构
│   ├── style.css
│   ├── boot.js
│   ├── hls.min.js
│   ├── app.js
│   ├── public-iptv-og.png
│   └── robots.txt
├── worker/
│   └── index.js               ← main：反馈 API + 静态资源回退
├── wrangler.jsonc             ← 关键：main / assets / ASSETS / run_worker_first
└── GitHub部署指南.md           ← 本文件（可以不传）
```

## 第 A2 步：改一行项目名（很重要）

用记事本打开 `wrangler.jsonc`，第一行的 `"name"`：

```jsonc
"name": "public-iptv-radio",
```

必须和 **Cloudflare 控制台里显示的 Worker/项目名完全一致**（你上次日志文件名里是 `public-iptv-radio`）。不一致会报 `The name in your Wrangler configuration file must match the name of your Worker` 直接失败。如果控制台里是别的名字，改成那个。

## 第 A3 步：GitHub 网页上传（不用 git 命令）

1. 打开 <https://github.com/new>，新建一个仓库，名字随意（例如 `public-iptv`），**不要**勾选 README / .gitignore（空仓库最干净）
2. 创建后点 **uploading an existing file**（或 Add file → Upload files）
3. 把 `cloudflare-workers-github` 文件夹**里的内容**拖进上传区 —— 确认 `wrangler.jsonc` 在仓库**根目录**，`public/` 和 `worker/` 是同级两个文件夹，没有多套一层
4. 点 **Commit changes**

## 第 A4 步：Cloudflare 连动仓库 ⭐

1. 控制台 → **Workers & Pages → Create → Workers → Connect to Git**（或进入已有项目 → Settings → Builds → Connect to Git）
   > 如果是编辑已有项目，先确认它的名字和 A2 里填的一致。
2. 授权 GitHub、选刚建的仓库、production branch 选 `main`
3. 构建设置逐项填：

| 字段 | 值 | 为什么 |
| --- | --- | --- |
| **Build command** | 留空（或 `exit 0`） | 纯静态资源，无需构建 |
| **Deploy command** | `npx wrangler deploy` | Workers Builds 默认值；这次有 `main` 了，不会再 `Missing entry-point` |
| **Root directory** | 留空 | 配置在仓库根 |
| **Preview command** | 保持默认 | 不影响生产 |

4. 保存，等第一次部署完成。日志里应该出现 `✨ Success`，网址是 `https://public-iptv-radio.<你的子域>.workers.dev`（或你自定义的名字）。

**此时先做一次关键验证**：浏览器直接访问

```
https://<你的站点>/api/feedback
```

- ✅ 返回一段 JSON（哪怕是 `{"ok":false,"service":"unconfigured"}`）→ **Worker 在跑了**，继续
- ❌ 返回 404 或首页 HTML → `main` 没被识别，检查 A3 的目录层级和 A2 的 name，重新部署

## 第 A5 步：加绑定（这次面板会解锁）

进项目 → **Settings → Bindings → Add → KV Namespace**：

| 字段 | 值 |
| --- | --- |
| Variable name | **`FEEDBACK`** |
| KV namespace | 选一个已有的，或这里直接新建 |

再进 **Settings → Variables and Secrets → Add**：

| 字段 | 值 |
| --- | --- |
| 类型 | **Secret / 运行时变量**（不要选 Build variable） |
| 名称 | **`ADMIN_TOKEN`** |
| 值 | 用密码管理器生成 32 位以上随机字符，复制保存好 |

> 🎯 这就是之前卡住的地方：因为 `wrangler.jsonc` 里有 `main`，项目不再是「只有静态资产的 Worker」，Bindings 面板现在可以正常添加。

## 第 A6 步：重新部署一次

绑定改动需要重新部署生效：项目 → **Deployments → 重新部署 / Retry deployment**，或者去 GitHub 网页随便改个文件 commit 一下触发构建。

## 第 A7 步：浏览器验证（不用命令）

1. 打开站点 → 星空 + 3D 地球 + 频道目录加载
2. 访问 `/api/feedback` → 应返回 `{"ok":true,"service":"feedback","provider":"KV"}`
3. 页面右上角「数据源」→ 反馈服务显示 **「已连接（KV）」**，反馈面板无橙色离线横幅
4. 提交一条 ≥5 字测试反馈 → 提示「已收到」→ 同面板「反馈管理」粘贴 `ADMIN_TOKEN` 点「读取」→ 能看到那条 →「导出 JSON」能下载

> KV 列表最终一致，刚提交可能等 5~10 秒才出现，稍等重读一次。

---

# B 包：Pages Git 集成（备选）

仅当控制台里能明确看到 **Create → Pages → Connect to Git** 时用。

```
cloudflare-pages-github/
├── public/                    index.html / style.css / boot.js / hls.min.js / app.js /
│                              public-iptv-og.png / robots.txt / _headers / _routes.json
├── functions/
│   └── api/feedback.js        ← Git 集成时由 Cloudflare 自动编译
├── wrangler.toml              ← name 必须与项目名一致
└── GitHub部署指南.md
```

步骤：

1. 同样改 `wrangler.toml` 里的 `name`，与控制台项目名一致
2. GitHub 网页上传整个目录，**`functions/` 必须在仓库根目录**（不能放进 `public/`）
3. 控制台 → **Create → Pages → Connect to Git** → 选仓库
4. 构建设置：

| 字段 | 值 |
| --- | --- |
| Framework preset | `None` |
| Build command | `exit 0` |
| Build output directory | `public` |
| Root directory | 留空 |
| **Deploy command** | **不要填**（若界面强制出现这个字段，说明进的是 Workers Builds，改回 A 包） |

5. 部署后 → Settings → Functions → **KV namespace bindings**（变量名 `FEEDBACK`）；Settings → Environment variables → **Add secret** `ADMIN_TOKEN`
6. 重新部署一次，按 A7 做四项验证

> 官方明确：Git 集成会编译根目录 `functions/`，而控制台拖拽上传不会 —— 这正是 B 包必须走 GitHub 的原因。

---

## 排错速查

| 现象 | 原因 | 怎么修 |
| --- | --- | --- |
| **「不能将绑定添加到只有静态资产的 Worker」** | 项目没有 `main`，被判定为 assets-only | 用 A 包；确认 `wrangler.jsonc` 在仓库根且含 `"main": "./worker/index.js"`，重新部署后面板会解锁 |
| `Missing entry-point to Worker script or to assets directory` | Deploy command 是 `npx wrangler deploy` 但配置里没 `main` | A 包的 `wrangler.jsonc` 已配 `main` + `assets.directory`；确认配置文件在仓库根、没被套进子文件夹 |
| `The name in your Wrangler configuration file must match...` | `name` 与控制台项目名不一致 | 改 `wrangler.jsonc` / `wrangler.toml` 第一行，重新 commit |
| `/api/feedback` 返回 404 或首页 HTML | Worker 没执行 | 检查 `worker/index.js` 路径、目录层级、部署日志是否成功 |
| `POST /api/feedback` 返回 **405** | 静态资产层只处理 GET/HEAD，把 POST 吃了 | `run_worker_first` 必须是 `true` 或 `["/api/*"]`（A 包已设 `true`） |
| 返回 `{"service":"unconfigured"}` / 503 | KV 没绑上或没重新部署 | 检查 Bindings 里变量名是 `FEEDBACK`；改完重新部署 |
| 管理读取提示「管理密钥不正确」 | `ADMIN_TOKEN` 值不对，或加成了 Build variable | 在 Variables and Secrets 里改成 **运行时 Secret**，值别带空格 |
| `ASSETS binding missing` 500 | `assets.binding` 没生效 | 确认 `wrangler.jsonc` 里 `"binding": "ASSETS"`，重新部署 |
| 页面样式/脚本全丢 | 上传时 `public/` 里文件没在根，或路径多一层 | 检查部署文件列表，确保 `style.css` / `app.js` 与 `index.html` 同级 |
| 频道播不了 | HTTPS 混合内容 | Cloudflare 强制 HTTPS，`http://` 直播源被拦截；点「换一个源」选 https。**不是部署问题** |

---

## 为什么这次和之前的拖拽包不一样

| | 之前的界面包 | 现在的 A 包 |
| --- | --- | --- |
| 后端形式 | `public/_worker.js`（被当静态文件） | `worker/index.js` + `wrangler.jsonc` 的 `main` |
| 项目类型 | assets-only Worker → 绑定面板禁用 | 真 Worker → 绑定面板解锁 |
| 部署方式 | 控制台拖拽 | GitHub 连动，Cloudflare 读配置 |
| `Missing entry-point` | 会报 | 有 `main`，不报 |
| 本地命令 | 无 | **仍然无**（命令都填在控制台表单里） |
| 反馈 | 时好时坏 | ✅ 完整可用（KV + 管理读取 + 导出） |

---

## 两个客观边界

- **Workers 请求额度**：A 包设了 `run_worker_first = true`，所有请求（含静态资源）都经过 Worker，计入 Workers 请求额度；免费计划对个人站点足够，流量极大时可改成 `["/api/*"]`（但那样静态响应就没有 Worker 补的安全头了）。B 包走 Pages 的 `_routes.json`，静态请求仍免费。
- **HTTPS 与第三方源**：`http://` 直播源会被按混合内容拦截；iptv-org / Radio Browser 可用性由对方决定；Cloudflare 免费节点在境外，面向中国大陆访客速度可能不稳定。请只使用你有权访问的公开流。
